﻿# ==========================================
# OAKHAVEN - GAME SETUP
# ==========================================

define config.main_menu_music = "audio/bgmusic.ogg"
define config.sample_sound = "audio/bgmusic.ogg"

define config.has_autosave = True
define config.autosave_on_quit = False
define config.autosave_frequency = None
define config.autosave_slots = 5

define config.game_menu_action = ShowMenu("preferences")

default preferences.text_cps = 40
default preferences.afm_enable = True
default preferences.afm_after_click = True
default preferences.afm_time = 8

default persistent.player_name = "Traveler"
default persistent.quest_1_2_unlocked = False
default persistent.chapter_1_2_unlocked = False
default persistent.chapter_2_unlocked = False
default persistent.ch2_activity_unlocked = False
default persistent.chapter_3_unlocked = False
default persistent.ch3_activity_unlocked = False
default persistent.chapter_4_unlocked = False
default persistent.ch4_activity_unlocked = False
default persistent.chapter_5_unlocked = False

default replay_mode = False
default guesa_solution_drawn = False
default answer = None
default q_hint = 0

# Quest 1.2
default quest_1_2_tries = 0
default guesa2_mass_gun = ""
default guesa2_mass_bullet = ""
default guesa2_vel_bullet = ""
default guesa2_unknown = ""
default guesa2_equation = ""
default guesa2_answer = ""

# Chapter 2 lesson
default ch2_m1 = ""
default ch2_V1 = ""
default ch2_m2 = ""
default ch2_V2 = ""
default ch2_vf = ""

# Quest 2
default q2_m1 = ""
default q2_u1 = ""
default q2_m2 = ""
default q2_u2 = ""
default q2_unknown = ""
default q2_equation = ""
default q2_vf = ""
default q2_ke = ""
default q2_tries = 0

# Chapter 3 lesson
default ch3_m1 = ""
default ch3_u1 = ""
default ch3_m2 = ""
default ch3_u2 = ""

# Quest 3
default q3_m1 = ""
default q3_u1 = ""
default q3_m2 = ""
default q3_u2 = ""
default q3_unknown = ""
default q3_equation = ""
default q3_v1f = ""
default q3_v2f = ""
default q3_dir = ""
default q3_tries = 0

# Quest 4
default q4_m1 = ""
default q4_u1 = ""
default q4_m2 = ""
default q4_u2 = ""
default q4_unknown = ""
default q4_equation = ""
default q4_vf = ""
default q4_ke = ""
default q4_tries = 0

# Quest 5
default q5_m1 = ""
default q5_u1 = ""
default q5_m2 = ""
default q5_u2 = ""
default q5_unknown = ""
default q5_equation = ""
default q5_vf = ""
default q5_ke = ""
default q5_dir = ""
default q5_tries = 0

# Checkpoints
default pretest_score = 0
default pretest_review = []
default pretest_i = 0
default mastery_score = 0
default mastery_review = []
default mastery_i = 0


# ==========================================
# PYTHON HELPERS
# ==========================================

init python:
    import re
    import math

    if "quick_menu" not in config.overlay_screens:
        config.overlay_screens.append("quick_menu")
    if "corner_logo" not in config.overlay_screens:
        config.overlay_screens.append("corner_logo")

    config.touch_keyboard = False

    # ---------- chapter select ----------
    chapter_list = [
        (1, "THE BEGINNING"),
        (2, "STICKY SITUATION"),
        (3, "STEEL FOR STEEL"),
        (4, "ONE WAY OR ANOTHER"),
    ]

    def chapter_open(n):
        if n == 1:
            return True
        flags = {
            2: persistent.chapter_2_unlocked,
            3: persistent.chapter_3_unlocked,
            4: persistent.chapter_4_unlocked,
        }
        return bool(flags.get(n, False))

    # ---------- saving ----------
    def safe_autosave():
        # chapter replays never overwrite the CONTINUE save
        if not store.replay_mode:
            renpy.force_autosave()

    def latest_save():
        best = None
        best_time = -1
        for page in ("auto", "1"):
            for i in range(1, 6):
                key = page + "-" + str(i)
                if renpy.can_load(key):
                    t = renpy.slot_mtime(key)
                    if t and t > best_time:
                        best_time = t
                        best = key
        return best

    def continue_game():
        key = latest_save()
        if key:
            renpy.load(key)

    # ---------- answer reading helpers ----------
    _QN = [
        ("₀", "0"), ("₁", "1"), ("₂", "2"), ("₃", "3"),
        ("ᵢ", "i"), ("ᵥ", "v"), ("ᵤ", "u"), ("ₓ", "x"),
        ("−", "-"), ("–", "-"), ("—", "-"),
        ("×", "*"), ("·", "*"), ("⋅", "*"),
        ("²", "^2"), ("³", "^3"), ("½", "1/2"),
    ]

    def qn(value):
        v = str(value).lower()
        for old, new in _QN:
            v = v.replace(old, new)
        return v

    def q_nums(value):
        v = qn(value).replace(",", "")
        return [float(x) for x in re.findall(r"-?\d*\.?\d+", v)]

    def q_has(value, target, tol=0.01):
        return any(math.isclose(n, target, abs_tol=tol) for n in q_nums(value))

    def has_ms_unit(value):
        v = qn(value).replace(" ", "").replace("*", "")
        accepted = ("m/s", "ms-1", "ms^-1", "ms⁻¹", "meterspersecond", "meterpersecond")
        return any(u in v for u in accepted)

    def q_vf_ok(value, target):
        v = qn(value).strip()
        return (not v.startswith("-")) and q_has(v, target, 0.02) and has_ms_unit(v)

    def q_ke_ok(value, target):
        v = qn(value).replace(",", "")
        sci = re.search(r"(\d+\.?\d*)\s*(?:x|\*)\s*10\s*\^?\s*(\d+)", v)
        if sci:
            val = float(sci.group(1)) * (10 ** int(sci.group(2)))
        else:
            m = re.search(r"\d*\.?\d+", v)
            if not m:
                return False
            val = float(m.group())
            if "kj" in v:
                val *= 1000
        return abs(val - target) <= target * 0.01 and "j" in v

    def q_solution_ok():
        return guesa_solution_drawn and len(scratch_pad.strokes) > 0

    def q_unknown_ok(value, need_dir=False):
        v = qn(value)
        has_v = any(k in v for k in ("velocity", "speed", "vf"))
        has_e = any(k in v for k in ("energy", "ke", "kinetic", "joule"))
        has_d = any(k in v for k in ("direction", "east", "west", "forward", "motion"))
        return has_v and has_e and (has_d or not need_dir)

    # ---------- QUEST 1.2 ----------
    def guesa2_check_given():
        return (q_has(guesa2_mass_gun, 4.5)
                and q_has(guesa2_mass_bullet, 0.015, 0.0006)
                and q_has(guesa2_vel_bullet, 280))

    def guesa2_check_unknown():
        v = qn(guesa2_unknown)
        return ("recoil" in v or "velocity" in v
                or re.search(r"\bv\s*_?\s*[a-z0-9]{0,6}\b", v) is not None)

    def quest_1_2_check(value):
        v = qn(value).strip().replace(",", "")
        match = re.search(r"(-?)\s*(\d*\.?\d+)", v)
        if not match:
            return False
        negative = match.group(1) == "-" or any(w in v for w in ("west", "backward", "opposite", "left"))
        number = float(match.group(2))
        return negative and math.isclose(number, 0.9333, abs_tol=0.015) and has_ms_unit(v)

    # ---------- QUEST 2: 85 kg at +7.0 m/s tackles 105 kg at rest ----------
    def q2_check_given():
        return (q_has(q2_m1, 85) and q_has(q2_u1, 7)
                and q_has(q2_m2, 105)
                and q_has(q2_u2, 0) and str(q2_u2).strip() != "")

    def q2_check_unknown():
        v = qn(q2_unknown)
        has_v = "velocity" in v or re.search(r"\bv\s*_?\s*f?\b", v) is not None
        has_e = "energy" in v or "ke" in v or "kinetic" in v
        return has_v and has_e

    # ---------- QUEST 3: 80 kg at +8.0 m/s, elastic, 40 kg at rest ----------
    def q3_check_given():
        return (q_has(q3_m1, 80) and q_has(q3_u1, 8)
                and q_has(q3_m2, 40)
                and q_has(q3_u2, 0) and str(q3_u2).strip() != "")

    def q3_check_unknown():
        v = qn(q3_unknown)
        has_v = any(k in v for k in ("velocit", "speed", "v1f", "v2f", "vf"))
        has_d = any(k in v for k in ("direction", "sign", "forward", "backward", "bounce", "motion"))
        return has_v and has_d

    def q3_check_v1f(value):
        v = qn(value).strip()
        return (not v.startswith("-")) and q_has(v, 2.67, 0.03)

    def q3_check_v2f(value):
        v = qn(value).strip()
        return (not v.startswith("-")) and q_has(v, 10.67, 0.03)

    def q3_check_dir(value):
        v = qn(value)
        bad = any(w in v for w in ("backward", "opposite", "negative", "bounce", "revers"))
        good = any(w in v for w in ("forward", "same", "positive", "+", "continue", "keeps", "east"))
        return good and not bad

    # ---------- QUEST 4: 120 kg at +5.0 m/s hits 80 kg at rest ----------
    def q4_check_given():
        return (q_has(q4_m1, 120) and q_has(q4_u1, 5)
                and q_has(q4_m2, 80)
                and q_has(q4_u2, 0) and str(q4_u2).strip() != "")

    # ---------- QUEST 5: 180 kg at 6.0 m/s hits 120 kg at rest ----------
    def q5_check_given():
        return (q_has(q5_m1, 180) and q_has(q5_u1, 6)
                and q_has(q5_m2, 120)
                and q_has(q5_u2, 0) and str(q5_u2).strip() != "")

    def q5_check_dir(value):
        v = qn(value)
        bad = any(w in v for w in ("west", "backward", "opposite", "negative"))
        good = (any(w in v for w in ("east", "forward", "same", "positive", "+"))
                or re.search(r"\be\b", v) is not None)
        return good and not bad

        # ---------- equation reading (order-proof) ----------
    def _eq_clean(text):
        c = qn(text)
        c = c.replace("ᶠ", "f").replace("(0)", "0")
        c = re.sub(r"[\s_*]", "", c)
        c = re.sub(r"\((m1\+m2|m2\+m1)\)", "M", c)   # (m1 + m2) becomes one factor "M"
        return c

    def _eq_tok(t, uconv):
        m = re.fullmatch(r"[uv]([12])i?", t)
        if m:
            # if the player uses u for initial, a bare v1 / v2 means final
            if uconv and t.startswith("v") and not t.endswith("i"):
                return "f" + m.group(1)
            return "i" + m.group(1)
        m = re.fullmatch(r"v([12]?)f?", t)
        if m and (t.endswith("f") or t == "v"):
            return "f" + m.group(1)
        return t

    def _eq_side(side, uconv):
        terms = []
        for term in side.split("+"):
            toks = re.findall(r"M|m[12]|[uv][12]?[if]?|\d*\.?\d+", term)
            if not toks or "".join(toks) != term:
                return None
            nums = [t for t in toks if t[0].isdigit() or t[0] == "."]
            if any(float(x) == 0 for x in nums):
                continue                              # a zero term drops out
            terms.append(tuple(sorted(_eq_tok(t, uconv) for t in toks)))
        return tuple(sorted(terms))

    def eq_parse(text):
        c = _eq_clean(text)
        if c.count("=") != 1:
            return None
        uconv = "u" in c
        left, right = c.split("=")
        l = _eq_side(left, uconv)
        r = _eq_side(right, uconv)
        if l is None or r is None:
            return None
        return tuple(sorted([l, r]))

    def eq_match(text, refs):
        got = eq_parse(text)
        return got is not None and got in [eq_parse(r) for r in refs]

    INELASTIC_REFS = ["m1v1i+m2v2i=(m1+m2)vf", "m1v1i=(m1+m2)vf"]
    MOMENTUM_REFS = ["m1v1i+m2v2i=m1v1f+m2v2f", "m1v1i=m1v1f+m2v2f"]
    RECOIL_REFS = ["0=m1v1f+m2v2f", "m1v1i+m2v2i=m1v1f+m2v2f"]

    def q45_check_equation(value):
        return eq_match(value, INELASTIC_REFS)

    def q2_check_equation():
        return eq_match(q2_equation, INELASTIC_REFS)

    def q3_check_equation():
        c = re.sub(r"[\s_*]", "", qn(q3_equation))
        shortcut = (("m1-m2" in c and "m1+m2" in c)
                    or ("2m1" in c and "m1+m2" in c))
        return shortcut or eq_match(q3_equation, MOMENTUM_REFS)

    def guesa2_check_equation():
        # keeps your old lenient check, and also accepts the full form
        c = re.sub(r"[\s_*()]", "", qn(guesa2_equation))
        terms = re.findall(r"m[a-z0-9]?v[a-z0-9]?", c)
        starts_at_zero = ("0=" in c) or ("=0" in c) or ("=-" in c)
        old_ok = len(terms) >= 2 and starts_at_zero
        return old_ok or eq_match(guesa2_equation, RECOIL_REFS)

        # answers we quietly accept but never show on screen
    QUIET_OK = ["m1v1i+m2v2i=m1v1f", "m1v1i-m2v2i=(m1+m2)vf"]

    def quiet_ok(text):
        c = _eq_clean(text)
        c = c.replace("ᶠ", "f").replace("u", "v")
        c = c.replace("(m1+m2)", "(m1+m2)")
        refs = [_eq_clean(r).replace("u", "v") for r in QUIET_OK]
        if c in refs:
            return True
        if c.count("=") == 1:
            l, r = c.split("=")
            return (r + "=" + l) in refs
        return False

    def q13_check_given():
        return q_has(q13_v1, 10) and q_has(q13_v2, 8)

    def q13_check_unknown():
        v = qn(q13_unknown)
        return ("restitution" in v or "coefficient" in v
                or re.search(r"\be\b", v) is not None)

    def q13_check_equation():
        c = re.sub(r"[\s_*()]", "", qn(q13_equation))
        return c.startswith("e=") and any(k in c for k in ("/", "÷", "over"))

    def q13_check_e():
        c = re.sub(r"\s", "", qn(q13_e)).replace("e=", "")
        return q_has(q13_e, 0.8, 0.005) or c in ("8/10", "4/5")

    def q13_check_type():
        v = qn(q13_type)
        return "inelastic" in v and "perfect" not in v

    # ---------- KNOWLEDGE CHECKPOINT (before Chapter 1) ----------
    pretest_questions = [
        {
            "q": "Which statement best describes collision?",
            "choices": [
                "Two objects move without interacting.",
                "Two or more objects interact and exert forces on each other for a period of time",
                "An object remains at rest indefinitely",
                "An object changes its mass while moving.",
            ],
            "answer": 1,
        },
        {
            "q": "In which type of collision is the total kinetic energy conserved?",
            "choices": [
                "Elastic collision",
                "Explosive Collision",
                "Inelastic Collision",
                "Perfectly Inelastic Collision",
            ],
            "answer": 0,
        },
        {
            "q": "A 2-kg object moving at 6m/s collides with a stationary 4-kg object. If they stick together after the collision, what is their final velocity?",
            "choices": [
                "1 m/s",
                "2 m/s",
                "3 m/s",
                "6 m/s",
            ],
            "answer": 1,
        },
        {
            "q": "What happens to the total momentum of an isolated system when two objects collide?",
            "choices": [
                "It increases after the collision",
                "It decreases after the collision",
                "It becomes zero after the collision",
                "It remains constant before and after the collision",
            ],
            "answer": 3,
        },
        {
            "q": "What happens to two objects during a perfectly inelastic collision?",
            "choices": [
                "They bounce apart after impact",
                "They move in opposite directions",
                "They maintain their original velocities",
                "They stick together and move with a common final velocity",
            ],
            "answer": 3,
        }
    ]

    # ---------- MASTERY CHECKPOINT (Sheriff Licensure Examination) ----------
    mastery_questions = [
        {
            "q": "What happens when two objects undergo a collision?",
            "choices": [
                "They interact and exert forces on each other.",
                "They automatically lose all their momentum.",
                "Their masses become equal.",
                "They must remain attached after impact.",
            ],
            "answer": 0,
        },
        {
            "q": "A 3-kg object moves at 4 m/s. What is its momentum?",
            "choices": [
                "7 kg·m/s",
                "8 kg·m/s",
                "12 kg·m/s",
                "16 kg·m/s",
            ],
            "answer": 2,
        },
        {
            "q": "Two objects collide and remain attached, moving together afterward. What type of collision occurs?",
            "choices": [
                "Elastic collision",
                "Perfectly inelastic collision",
                "Explosive collision",
                "Perfectly elastic collision",
            ],
            "answer": 1,
        },
        {
            "q": "Which statement correctly explains the behavior of total momentum in an isolated system during a collision?",
            "choices": [
                "Total momentum continuously increases.",
                "Total momentum decreases after impact.",
                "Total momentum remains unchanged before and after the collision.",
                "Total momentum becomes zero once the objects collide.",
            ],
            "answer": 2,
        },
        {
            "q": "In a perfectly inelastic collision, how do the colliding objects move immediately after impact?",
            "choices": [
                "They separate and move independently.",
                "They combine and continue moving with the same velocity.",
                "They bounce back in opposite directions.",
                "They retain their respective initial velocities.",
            ],
            "answer": 1,
        }
    ]


# ==========================================
# CHARACTER POSITIONS
# ==========================================

transform pos_left:
    xanchor 0.5
    xpos 0.2
    yalign 1.0

transform pos_center:
    xanchor 0.5
    xpos 0.5
    yalign 1.0

transform pos_right:
    xanchor 0.5
    xpos 0.8
    yalign 1.0


# ==========================================
# TRANSITIONS
# ==========================================

define slide = MoveTransition(0.8)
define slow_slide = MoveTransition(1.5)


# ==========================================
# CHARACTERS
# ==========================================

define h = Character("Hugo Vector", color="#C69A5D")
define n = Character("[persistent.player_name]", color="#FFFFFF")
define t1 = Character("Townsperson", color="#B0B0B0")
define narrator = Character(None)
define s = Character("Selena Colm", color="#9e1414")
define kid = Character("The Kid", color="#7FB3D5")


# ==========================================
# IMAGES
# ==========================================

image ye = Transform("images/ye.png", zoom=1.0)

image intro_background = "images/intro1.png"
image chap2 = "images/chap2.png"
image chap3 = "images/chap3.png"
image chap4_1 = "images/chap4_1.png"
image chap4_2 = "images/chap4_2.png"
image chap5 = "images/disaster.png"

# Ending cutscene images
image c5_1 = "images/c5pic.png"
image c5_2 = "images/c5pic2.png"
image c5_3 = "images/timeskip_player.png"

# HUGO
image hugo plain = "images/hugo_plain.png"
image hugo smirk = "images/hugo_smirk.png"
image hugo hah = "images/hugo_hah.png"
image hugo ehe = "images/hugo_ehe.png"
image hugo hehe = "images/hugo_hehe.png"
image hugo smile = "images/hugo_smile.png"
image hugo shy = "images/hugo_shy.png"
image hugo aha = "images/hugo_aha.png"
image hugo sher = "images/hugo_sher.png"
image hugo happy = "images/hugo_happy.png"
image hugo = "images/hugo.png"
image hugo excited = "images/hugo_excited.png"
image hugo sad = "images/hugo_sad.png"
image hugo serious = "images/hugo_serious.png"
image hugo mad = "images/hugo_mad.png"
image hugo hufo = "images/hugo_hufo.png"
image hugo lala = "images/hugo_lala.png"

# PLAYER (chapter 1)
image ye mad = "images/ye_mad.png"
image ye serious = "images/ye_serious.png"
image ye normal = "images/ye_normal.png"
image ye yes = "images/ye_yes.png"
image ye hes = "images/ye_hes.png"
image ye hm = "images/ye_hm.png"
image ye rlly = "images/ye_rlly.png"
image ye hips = "images/ye_hips.png"
image ye goe = "images/ye_goe.png"
image ye sasageyo = "images/ye_sasageyo.png"
image ye standcape = "images/ye_standcape.png"
image ye sad2 = "images/ye_sad2.png"

# PLAYER (chapters 2 - 4)
image ye b = "images/ye_b.png"
image ye c = "images/ye_c.png"
image ye d = "images/ye_d.png"
image ye h = "images/ye_h.png"
image ye capehand = "images/capehand.png"
image ye fight = "images/fight.png"
image ye normaly = "images/normaly.png"
image ye ohno = "images/ohno.png"
image ye s_stand = "images/s_stand.png"
image ye sad = "images/sad.png"
image ye shys = "images/shys.png"
image ye stand = "images/stand.png"
image ye ugh = "images/ugh.png"
image ye weh = "images/weh.png"
image ye whamn = "images/whamn.png"
image ye what = "images/what.png"
image ye smile = "images/smile.png"

# SELENA
image selena 1 = "images/selena_1.png"
image selena 2 = "images/selena_2.png"
image selena 3 = "images/selena_3.png"
image selena 4 = "images/selena_4.png"
image selena 5 = "images/selena_5.png"
image selena 6 = "images/selena_6.png"
image selena 7 = "images/selena_7.png"
image selena 8 = "images/selena_8.png"
image selena 9 = "images/selena_9.png"
image selena 10 = "images/selena_10.png"


# ==========================================
# OPENING TRAILER
# ==========================================

label splashscreen:

    $ renpy.movie_cutscene("videos/trailer.webm")

    return


# ==========================================
# INTRO DIALOGUE
# ==========================================

label intro_dialogue:

    scene intro1
    with fade

    play music "audio/w4.ogg" fadein 1.0

    show ye rlly at pos_center
    with dissolve

    n "The Oakhaven Gazette. Front page again. Two supply wagons were hijacked near the ridge, and another break-in at the iron depot last night."

    show ye yes at pos_right
    with slide

    show hugo hehe at pos_left
    with slide

    h "Ah, good morning to you too, Kid. Lovely weather we’re having. Perfect day for bad news."

    show ye normal at pos_right
    with slide

    n "Crime is up thirty percent since you’ve been off the streets this month, Hugo. The outlaws know it and are taking advantage of your situation."

    show hugo smile at pos_left
    with slide

    h "Hey, sitting behind a desk is hard work. My spine is fighting a war of its own. Besides... that's why I have you."

    n "I file the incident reports, keep track of the armory inventory, and make sure the town doesn't run out of official letterhead. That’s my job."

    h "Was your job."

    h "Starting today, you’re stepping out from behind that stack of paperwork."

    show ye mad at pos_right
    with slide

    n "No."

    show hugo shy at pos_left
    with slide

    h "\"No\"? Just like that? No grand speech? No emotional drama?"

    show ye hes at pos_right
    with slide

    n "I’m a clerk, Hugo. Not a hero. You pull off impossible trick shots and stop runaway carriages with your bare hands—or at least you used to."
    n "I’m just ordinary. I don't have the strength, the speed, or the nerves to stand up to people like Selena Colm."
    n "If I go out there, it's like I'm asking for a death wish."

    show hugo aha at pos_left
    with slide

    h "(He sighs, his tone shifting from casual to earnest) Kid... look at me. Look at this arm."
    h "Colm’s men made sure I’d never draw a revolver fast enough to win a quick-draw duel ever again."
    h "If muscle and raw speed were the only things that made a sheriff, Oakhaven would already be burned to the ground."

    show ye normal at pos_right
    with slide

    n "That’s my point. You were a legend, and even you got hurt. What chance do I have?"

    show hugo serious at pos_left
    with slide

    h "You think I stopped those runaway train cars with brute force?"

    show hugo sher at pos_left
    with slide

    h "It was all up here. I didn't out-fight those bandits—I out-calculated them."
    h "When a thirty-ton cart comes barreling down the track, you don't stand in front of it and pray your muscles hold out."
    h "You look at the collision before it happens. Is it going to bounce off cleanly and keep its speed, or is it going to crumple, lock couplers, and stick?"
    h "Momentum carries the punch, Kid... "
    h "but impulse controls how hard it hits. Power is loud..."
    h "but collisions follow rules."

    show ye hes at pos_right
    with slide

    n "Rules don't stop a five-ton cargo car from smashing into a barricade."

    show hugo hah at pos_left
    with slide

    h "No, but knowing how momentum transfers during an impact sure helps you decide where all that energy goes."
    h "You don't need to be strong. You just need to know how to cushion the blow or turn the rebound against them."
    h "And lucky for you, the only tool you’re actually going to need out there is... physics."

    show ye hm at pos_right
    with slide

    n "...Physics? How is physics supposed to keep me from getting thrown off a moving train?"

    show hugo happy at pos_left
    with slide

    h "Oh, Deputy... physics is the only reason you can catch a moving freight car, absorb its kinetic energy, and land on your feet instead of breaking every bone in your body."
    h "Come on, let me show you how momentum and collisions really work."

    hide hugo
    hide ye
    scene black
    with fade

    return


# ==========================================
# KNOWLEDGE CHECKPOINT
# ==========================================

label pretest:

    $ pretest_score = 0
    $ pretest_review = []
    $ pretest_i = 0

    while pretest_i < len(pretest_questions):

        python:
            item = pretest_questions[pretest_i]
            pick = renpy.call_screen(
                "pretest_question",
                pretest_i + 1,
                len(pretest_questions),
                item["q"],
                item["choices"]
            )

            ok = (pick == item["answer"])
            if ok:
                pretest_score += 1

            pretest_review.append({
                "q": item["q"],
                "picked": item["choices"][pick],
                "correct": item["choices"][item["answer"]],
                "ok": ok
            })

            pretest_i += 1

    call screen pretest_results(pretest_score, len(pretest_questions), pretest_review)

    stop music fadeout 1.0

    return


# ==========================================
# START GAME
# ==========================================

label start:

    $ replay_mode = False

    $ renpy.movie_cutscene("videos/intro.webm")

    call intro_dialogue

    call pretest

    call screen chapter_title(1, "THE BEGINNING", "images/intro1.png")

    jump chapter1_dialogue


# ==========================================
# CHAPTER SELECT ENTRY POINTS
# (replay_mode stops these runs from overwriting the CONTINUE save)
# ==========================================

label replay_entry_1:
    $ replay_mode = True
    call screen chapter_title(1, "THE BEGINNING", "images/intro1.png")
    jump chapter1_dialogue

label replay_entry_2:
    $ replay_mode = True
    jump chapter2_dialogue

label replay_entry_3:
    $ replay_mode = True
    jump chapter3_dialogue

label replay_entry_4:
    $ replay_mode = True
    jump chapter4_dialogue


# ==========================================
# CHAPTER 1 - LINEAR MOMENTUM
# ==========================================

label chapter1_dialogue:

    $ safe_autosave()

    scene intro1
    with fade

    play music "audio/w2.ogg" fadein 1.0

    show hugo aha at pos_center
    with slide

    h "To kick things off, let’s start with the absolute fundamentals of what you're going to face out on these trails."
    h "Today, we're talking about collisions."

    show hugo happy at pos_left
    with slide

    show ye rlly at pos_right
    with slide

    n "Really, Hugo? A physics lecture? Now? While the entire town is in danger?"

    show hugo smirk at pos_left
    with slide

    show ye mad at pos_right
    with slide

    h "Hey, don't give me that look. Slow down, breathe. We have plenty of time to get our bearings, and besides, before you try facing outlaws in the field, you must master the fundamentals first. Out here, a rushed lawman is a dead lawman."

    show ye normal at pos_right
    with slide

    n "Fine, fine... I'm listening. What's so complicated about things crashing into each other? They hit, and somebody stops. Right?"

    show hugo happy at pos_left
    with slide

    h "If only it were that simple, Kid. A collision is an interaction in which objects exert forces on each other over a relatively short time."
    h "If external impulse is negligible, total momentum is conserved in all of them. But the types differ entirely in whether total kinetic energy is conserved."

    show ye yes at pos_right
    with slide

    n "Alright, lay it on me. What kind of types are we talking about?"

    show hugo excited at pos_left
    with slide

    h "There are two main types of collisions: Elastic Collision and Inelastic Collision."

    show hugo happy at pos_left
    with slide

    h "In elastic collisions, the kinetic energy is conserved. Meaning objects simply trade velocities and bounce apart from each other without losing energy and momentum."

    show ye yes at pos_right
    with slide

    n "So like... hard objects bouncing off each other cleanly without losing a thing?"

    show hugo smile at pos_left
    with slide

    h "Spot on, Deputy! But out on the frontier, things rarely work out that neatly."

    show ye rlly at pos_right
    with slide

    n "Let me guess—that's where the second type comes in?"

    show hugo excited at pos_left
    with slide

    h "Precisely. On the other hand, we have inelastic collisions, which are collisions when the kinetic energy is not conserved."
    h "Basically, instead of objects cleanly bouncing apart, they dent, crumple, and stick together after the collision."
    h "While the total momentum is still conserved, some of its kinetic energy gets lost and turns into other kinds of energy, such as heat or sound energy."

    show ye yes at pos_right
    with slide

    n "And what if they don't just dent or crumple, but just stick and lock together entirely?"

    show hugo excited at pos_left
    with slide

    h "Ah, that brings us to a special case! A special case for inelastic collision is called the perfectly inelastic collision."
    h "Unlike some inelastic collisions where objects get crushed, a perfectly inelastic collision is where objects simply stick together after colliding, moving as a single, combined mass from that point on."

    show ye rlly at pos_right
    with slide

    show hugo ehe at pos_left
    with slide

    n "Let me make sure I've got it straight"
    n "momentum is always conserved because the impact duration is the exact same for both objects, and the forces are equal and opposite"
    n "—so whatever momentum one object loses, the other object gains."
    n "But kinetic energy isn't conserved in inelastic ones because it gets converted into other, non-motion forms of energy during the crash."

    show hugo ehe at pos_left
    with slide

    h "Couldn't have said it better myself, Deputy."
    h "Now try this!"

    jump quest_1_try


label quest_1_try:

    $ answer = renpy.call_screen(
        "mcq_screen",
        title="QUEST 1.1 - TYPES OF COLLISIONS",
        problem="Two heavy railway carts collide on the tracks. Cart A slams into stationary Cart B, and instead of bouncing away, they lock bumpers and slide down the track together as one combined wreckage. What type of collision is this?",
        choices=[
            "Perfectly Elastic Collision",
            "Perfectly Inelastic Collision",
            "Explosive Collision"
        ],
        hint_text="Look at what the carts do after the crash. Do they bounce apart, or move together as one?"
    )

    if answer == "Perfectly Inelastic Collision":

        n "They locked together and moved as one, so it's perfectly inelastic."

        h "Exactly right, Deputy!"

    else:

        h "Not quite, Deputy. Think about what happens to the carts after they collide."

        $ renpy.notify("Try again! You can use the hint.")

        jump quest_1_try

    show hugo happy at pos_left
    with slide

    h "Our final review topic is the Law of Conservation of Linear Momentum, it’s a fundamental concept to take in mind when it comes to solving collisions."
    h "It states that the total linear momentum of a system remains constant when the system has zero net external force."
    h "For two objects interacting in one dimension:"

    show screen formula_card(
        "CONSERVATION OF LINEAR MOMENTUM",
        "m₁v₁i + m₂v₂i = m₁v₁f + m₂v₂f",
        "m₁, m₂ = masses\nv₁i, v₂i = initial velocities\nv₁f, v₂f = final velocities"
    )

    show hugo happy at pos_left
    with slide

    show ye normal at pos_right
    with slide

    n "So even if the objects exchange momentum during a collision, the system's total momentum stays the same, as long as the net external force is zero?"

    show hugo excited at pos_left
    with slide

    h "That's correct! Individual objects can change their momentum, but the total momentum of the system remains conserved."

    show ye rlly at pos_right
    with slide

    n "And if two carts collide and stick together, they'll move with one common final velocity?"

    show hugo sher at pos_left
    with slide

    h "Exactly. That's a perfectly inelastic collision. The objects share a final velocity, and the total momentum is conserved if external impulses are negligible. But that’s a topic to be covered later on."
    h "For now, let’s focus on recoil. Recoil occurs when objects move in opposite directions after pushing apart or interacting."
    h "If the system starts at rest and external impulse is negligible, their momenta are equal in magnitude and opposite in direction. Take this as an example:"

    hide screen formula_card

    # ---------- G.U.E.S.A. METHOD - EXAMPLE ----------

    show hugo happy at pos_left
    with dissolve

    h "Before we move on, let me show you how we can organize this problem using the G.U.E.S.A. method."

    h "G.U.E.S.A. stands for Given, Unknown, Equation, Solution, and Answer."

    show ye normal at pos_right
    with slide

    n "So, it's a way to organize the steps when solving physics problems?"

    show hugo hehe at pos_left
    with slide

    h "Exactly! Let's use our rifle recoil problem as an example: a 3.0-kilogram rifle at rest fires a 0.005-kilogram bullet at positive 300 meters per second. Find the rifle's recoil velocity."

    h "First, G stands for Given. We list all the information provided in the problem."

    h "We'll call the rifle object 1 and the bullet object 2. The rifle has a mass of 3.0 kilograms, while the bullet has a mass of 0.005 kilograms."

    h "Both are initially at rest, and the bullet leaves the barrel at positive 300 meters per second."

    show screen solution_card("G.U.E.S.A. - RIFLE RECOIL", [
        "GIVEN:  m₁ = 3.0 kg (rifle),  m₂ = 0.005 kg (bullet)",
        "v₁i = 0 m/s,  v₂i = 0 m/s,  v₂f = +300 m/s"
    ])

    h "Next, U stands for Unknown. We identify what the problem asks us to find."

    h "Here, we're looking for the rifle's recoil velocity, v₁f."

    show screen solution_card("G.U.E.S.A. - RIFLE RECOIL", [
        "GIVEN:  m₁ = 3.0 kg (rifle),  m₂ = 0.005 kg (bullet)",
        "v₁i = 0 m/s,  v₂i = 0 m/s,  v₂f = +300 m/s",
        "UNKNOWN:  v₁f (the rifle's recoil velocity)"
    ])

    h "E stands for Equation. Since the system's initial momentum is zero, we use the conservation of linear momentum."

    show screen solution_card("G.U.E.S.A. - RIFLE RECOIL", [
        "GIVEN:  m₁ = 3.0 kg (rifle),  m₂ = 0.005 kg (bullet)",
        "v₁i = 0 m/s,  v₂i = 0 m/s,  v₂f = +300 m/s",
        "UNKNOWN:  v₁f (the rifle's recoil velocity)",
        "EQUATION:  m₁v₁i + m₂v₂i = m₁v₁f + m₂v₂f",
        "0 = m₁v₁f + m₂v₂f"
    ])

    h "S stands for Solution. We rearrange the equation to isolate the rifle's velocity, then substitute the known values and calculate."

    show screen solution_card("G.U.E.S.A. - RIFLE RECOIL", [
        "GIVEN:  m₁ = 3.0 kg (rifle),  m₂ = 0.005 kg (bullet)",
        "v₁i = 0 m/s,  v₂i = 0 m/s,  v₂f = +300 m/s",
        "UNKNOWN:  v₁f (the rifle's recoil velocity)",
        "EQUATION:  m₁v₁i + m₂v₂i = m₁v₁f + m₂v₂f",
        "0 = m₁v₁f + m₂v₂f",
        "SOLUTION:  v₁f = −m₂v₂f / m₁",
        "v₁f = −(0.005 kg)(+300 m/s) / (3.0 kg)"
    ])

    h "The result is negative 0.50 meters per second."

    h "Finally, A stands for Answer. We state the result clearly, including its direction."

    show screen solution_card("G.U.E.S.A. - RIFLE RECOIL", [
        "GIVEN:  m₁ = 3.0 kg (rifle),  m₂ = 0.005 kg (bullet)",
        "v₁i = 0 m/s,  v₂i = 0 m/s,  v₂f = +300 m/s",
        "UNKNOWN:  v₁f (the rifle's recoil velocity)",
        "EQUATION:  m₁v₁i + m₂v₂i = m₁v₁f + m₂v₂f",
        "0 = m₁v₁f + m₂v₂f",
        "SOLUTION:  v₁f = −m₂v₂f / m₁",
        "v₁f = −(0.005 kg)(+300 m/s) / (3.0 kg)",
        "ANSWER:  v₁f = −0.50 m/s"
    ])

    n "−0.50 m/s, opposite the bullet’s direction. The rifle moves backward so the total momentum of the rifle–bullet system remains zero."

    hide screen solution_card

    h "Correct! Just always remember, despite exchanging momentums, the total momentum stays the same in initial and final, as long as the net external force is zero."

    show ye yes at pos_right
    with slide

    n "Got it. G.U.E.S.A. helps us organize the information and understand each step of the solution."

    show hugo excited at pos_left
    with slide

    h "That's right, Deputy. Keep those five steps in mind whenever you're solving a physics problem."

    jump quest_1_2


# ==========================================
# QUEST 1.2 - GUESA WITH WHITEBOARD + HINTS
# ==========================================

label quest_1_2:

    $ safe_autosave()

    $ quest_1_2_tries = 0
    $ guesa_solution_drawn = False
    $ scratch_pad.clear()

    $ guesa2_mass_gun = ""
    $ guesa2_mass_bullet = ""
    $ guesa2_vel_bullet = ""
    $ guesa2_unknown = ""
    $ guesa2_equation = ""
    $ guesa2_answer = ""

    scene intro1
    with fade

    show hugo happy at pos_left
    with dissolve

    show ye normal at pos_right
    with dissolve

    h "Now it's your turn, Deputy. Use the G.U.E.S.A. method, and write your solution on the whiteboard."

    jump quest_1_2_try


label quest_1_2_try:

    call screen quest_form("q12")

    $ g_ok = guesa2_check_given()
    $ u_ok = guesa2_check_unknown()
    $ e_ok = guesa2_check_equation()
    $ s_ok = q_solution_ok()
    $ a_ok = quest_1_2_check(guesa2_answer)

    if g_ok and u_ok and e_ok and s_ok and a_ok:

        $ persistent.quest_1_2_unlocked = True
        $ persistent.chapter_2_unlocked = True

        show hugo excited at pos_left
        with slide

        show screen solution_card("QUEST 1.2 - SOLUTION", [
            "GIVEN:  m₁ = 4.5 kg (shotgun),  m₂ = 0.015 kg (bullet)",
            "v₁i = 0 m/s,  v₂i = 0 m/s,  v₂f = +280 m/s",
            "0 = m₁v₁f + m₂v₂f",
            "v₁f = −m₂v₂f / m₁",
            "v₁f = −(0.015 kg)(+280 m/s) / (4.5 kg)",
            "v₁f ≈ −0.93 m/s"
        ])

        n "The shotgun kicks backward at about 0.93 m/s."

        h "Spot on, Deputy! The negative sign shows it moves opposite the bullet."

        hide screen solution_card

        jump quest_1_3

    else:

        $ quest_1_2_tries += 1

        show hugo smirk at pos_left
        with slide

        if not g_ok:
            h "Check your Given. Masses in kg, and the bullet's velocity with its sign."
        elif not u_ok:
            h "What is the problem actually asking for? Name the unknown."
        elif not e_ok:
            h "Your equation is off. The system starts at rest, so total initial momentum is zero."
        elif not s_ok:
            h "Show me your solution on the whiteboard, then press DONE."
        else:
            h "Close, but check your answer. Don't forget the sign and unit, because the recoil goes opposite the bullet."

        $ renpy.notify("Try again!")

        jump quest_1_2_try

# ==========================================
# QUEST 1.3 - COEFFICIENT OF RESTITUTION
# ==========================================

default q13_v1 = ""
default q13_v2 = ""
default q13_unknown = ""
default q13_equation = ""
default q13_e = ""
default q13_type = ""
default q13_tries = 0

label quest_1_3:

    $ safe_autosave()

    scene intro1
    with fade

    show hugo happy at pos_left
    with dissolve

    show ye normal at pos_right
    with dissolve

    h "Alright, Deputy. We've talked about elastic collisions where things bounce clean, and inelastic ones where they stick or crush. But how do we actually measure how bouncy or stubborn an object is when it hits?"

    show ye rlly at pos_right
    with slide

    n "Let me guess, another formula with Greek letters and fractions?"

    show hugo excited at pos_left
    with slide

    h "Bingo! Meet the Coefficient of Restitution, denoted by the letter e."

    show ye hm at pos_right
    with slide

    n "Restitution? Like restoring order?"

    show hugo sher at pos_left
    with slide

    h "Close! Restitution refers to how a surface or object recovers after being deformed. The coefficient of restitution is a unitless number that measures how elastic a collision is."
    h "It compares how fast objects separate after a crash to how fast they were approaching before the crash."

    show ye yes at pos_right
    with slide

    n "So it's basically how bouncy an object is?"

    show hugo smile at pos_left
    with slide

    h "Precisely. Mathematically, it's defined as:"

    show screen formula_card(
        "COEFFICIENT OF RESTITUTION",
        "e = (Relative speed after collision)\n      / (Relative speed before collision)\n   = (v₂f − v₁f) / (v₁i − v₂i)",
        "e is unitless"
    )

    h "Depending on the value of e, we can tell exactly what kind of collision we're dealing with:"

    show screen formula_card(
        "e = 1  (PERFECTLY ELASTIC)",
        "No kinetic energy is lost.",
        "Objects bounce apart with the exact same relative speed they had when they approached. Think of ideal steel balls."
    )

    h "First, e equals 1. That's a perfectly elastic collision. No kinetic energy is lost, and the objects bounce apart with the exact same relative speed they had when they approached. Think of ideal steel balls."

    show screen formula_card(
        "0 < e < 1  (INELASTIC)",
        "Some kinetic energy is lost.",
        "A real-world collision. Energy goes to sound, heat, or metal bending, so objects separate slower than they approached."
    )

    h "Next, e between 0 and 1. That's an inelastic collision, the real-world kind. Some kinetic energy is lost to sound, heat, or metal bending, so the objects separate slower than they approached."

    show screen formula_card(
        "e = 0  (PERFECTLY INELASTIC)",
        "Zero bounce.",
        "The objects stick together completely and move as one."
    )

    h "And e equals 0. That's a perfectly inelastic collision. Zero bounce. The objects stick together completely and move as one."

    hide screen formula_card

    show ye normaly at pos_right
    with slide

    n "So if a runaway cart crashes into our barricade and locks tight without rebounding an inch, its coefficient of restitution is practically zero."

    show hugo excited at pos_left
    with slide

    h "Spot on, Deputy! You've officially got the hang of it. Now let's see if you can calculate it before Selena's scouts test our fences again."

    $ safe_autosave()

    $ q13_tries = 0
    $ guesa_solution_drawn = False
    $ scratch_pad.clear()
    $ q13_v1 = ""
    $ q13_v2 = ""
    $ q13_unknown = ""
    $ q13_equation = ""
    $ q13_e = ""
    $ q13_type = ""

    jump quest_1_3_try


label quest_1_3_try:

    call screen quest_form("q13")

    $ g_ok = q13_check_given()
    $ u_ok = q13_check_unknown()
    $ e_ok = q13_check_equation()
    $ s_ok = q_solution_ok()
    $ a_ok = q13_check_e()
    $ t_ok = q13_check_type()

    if g_ok and u_ok and e_ok and s_ok and a_ok and t_ok:

        show hugo excited at pos_left
        show ye capehand at pos_right
        with slide

        show screen solution_card("QUEST 1.3 - SOLUTION", [
            "e = (speed after collision) / (speed before collision)",
            "e = (8 m/s) / (10 m/s)",
            "e = 0.8",
            "0 < e < 1, so the collision is inelastic"
        ])

        n "Rebound speed over approach speed... that's 8 divided by 10, which gives us e = 0.8! Meaning the collision is inelastic."

        h "Great work, Kid!"

        hide screen solution_card

        jump chapter1_completion

    else:

        $ q13_tries += 1

        show hugo smirk at pos_left
        with slide

        if not g_ok:
            h "Check your Given. The approach speed and the rebound speed, both in m/s."
        elif not u_ok:
            h "What is the problem actually asking for? Name the unknown."
        elif not e_ok:
            h "Your equation is off. e is the speed after the collision divided by the speed before it."
        elif not s_ok:
            h "Show me your solution on the whiteboard, then press DONE."
        elif not a_ok:
            h "Close, but check your answer. Divide the rebound speed by the approach speed. Remember, e has no unit."
        else:
            h "Check the type of collision. Compare your e to the ranges: 1, between 0 and 1, and 0."

        $ renpy.notify("Try again!")

        jump quest_1_3_try


# ==========================================
# CHAPTER 1 - COMPLETION SCENE
# ==========================================

label chapter1_completion:

    scene intro1
    with fade

    show hugo happy at pos_left
    with dissolve

    show ye normal at pos_right
    with dissolve

    h "How's the paperwork, Deputy?"

    show ye rlly at pos_right
    with slide

    n "You mean the physics worksheets you forced me to answer? Yes. But I still don't understand how all these concepts are going to help me fight crime."

    show ye hes at pos_right
    with slide

    n "I don't think I'd be able to think straight out there. I don't even think I'd have enough time to solve it before the collision happens."

    n "Just... find someone better, more capable than me. You're betting on a lost cause."

    show hugo sad at pos_left
    with slide

    h "Kid... we've been through this, remember--"

    show ye sasageyo at pos_right
    with slide

    n "I don't have the brains, Hugo! I'm not strong enough to stop anything at all! I'm better off doing all your paperwork for all I care!"

    n "I don't think this is going to work, Sheriff."

    hide ye
    with dissolve

    "(The player walks out of the room.)"

    # play sound "audio/cart.ogg"
    "(Cart noises)"

    t1 "Help! Somebody help! My supply cart--!"

    "(Noise)"

    show hugo shy at pos_center
    with slide

    h "Seems like they need you, Kid. You're the only person here capable of stopping it."

    "(He hands over the notebook the player used for solving.)"

    show ye hips at pos_right
    with dissolve

    n "You place too much hope on someone like me."

    "(The player takes the notebook.)"

    show ye standcape at pos_right
    with slide

    n "But if you, of all people, believe that I'm truly capable, then I'll try to hold onto that belief."

    show hugo excited at pos_center
    with slide

    h "That's my Sheriff! Thinking like a real lawman. Keep those lessons close, you'll need them."

    show ye goe at pos_right
    with slide

    n "Linear momentum, impulse, Newton's Second Law, and conservation of momentum... I still have a lot to learn. But I think I'm ready to try."

    hide hugo
    hide ye
    scene black
    with fade

    call screen chapter_card("CHAPTER 1 COMPLETE")

    jump chapter2_dialogue


# ==========================================
# CHAPTER 2 - STICKY SITUATION
# ==========================================

label chapter2_dialogue:

    $ safe_autosave()

    call screen chapter_title(2, "STICKY SITUATION", "images/chap2.png")

    scene chap2
    with fade

    stop music fadeout 1.0
    play music "audio/w1.ogg" fadein 1.0

    "Right outside the Sheriff's office on Oakhaven's main sloped street. The dust from the doorway is still settling as the Player walks out, clutching the physics notebook Hugo just handed them."

    # play sound "audio/cart_rattle.ogg"
    "(Wooden cart wheels rattle violently on dirt and cobblestones, accompanied by panicked shouting.)"

    t1 "Help! Somebody help! My supply cart--!"

    show ye ohno at pos_right
    with slide

    n "This is bad... That supply cart broke its wooden chocks! It's rolling straight toward the mercantile porch!"

    show hugo smile at pos_left
    with slide

    h "Let's put what you've learned into action, Deputy. You've got the equations right there in your hands. Time to put that notebook to work!"

    show ye weh at pos_right
    with slide

    "(Heart pounding, the Player grips the notebook tightly and breaks into a full sprint alongside the runaway cart.)"

    n "You've got to be kidding me! Right now?! I barely had time to read the cover!"

    show hugo lala at pos_left
    with slide

    h "(Calling out over the rushing wind and rolling wheels) Physics doesn't wait for office hours, Kid! Look at the mass! Look at the velocity! Calculate the system before it hits that porch!"

    show ye ohno at pos_right
    with slide

    n "I'm beginning to rethink my life choices...!"

    jump chapter2_lesson


# ==========================================
# CHAPTER 2 - LESSON PROPER: INELASTIC COLLISION
# ==========================================

label chapter2_lesson:

    show hugo shy at pos_left
    show ye ugh at pos_right
    with slide

    h "Alright, Deputy. Let's break down the math behind this."

    n "Hugo! Now's not the time for doing the math!"

    show hugo smirk at pos_left
    with slide

    h "We have plenty of time, Kid. In physics, when two objects collide and stick together, like your supply cart locking onto that stationary timber cart, we call it what?"

    jump ch2_q_type


label ch2_q_type:

    $ answer = renpy.call_screen(
        "mcq_screen",
        title="TYPE OF COLLISION",
        problem="Two objects collide and stick together, like the supply cart locking onto the stationary timber cart. What do we call this?",
        choices=[
            "Inelastic Collision",
            "Perfectly Inelastic Collision",
            "Perfectly Elastic Collision"
        ],
        hint_text="They stick together and move as one combined mass."
    )

    if answer == "Perfectly Inelastic Collision":

        show ye stand at pos_right
        with slide

        n "Perfectly inelastic collision."

        show hugo hah at pos_left
        with slide

        h "You've got it! Let's look at what the Law of Conservation of Momentum is telling us: the total momentum of a system before a collision is equal to the total momentum of the system after a collision, as long as there are no external net forces acting on it."

    else:

        show hugo serious at pos_left
        with slide

        h "Not quite. Think about what happens to the carts after they lock together."

        $ renpy.notify("Try again! You can use the hint.")

        jump ch2_q_type

    show ye normaly at pos_right
    with slide

    n "So basically, even after the collision, when two objects have different momenta, their combined final momentum is still equal to the total momentum before the collision."

    show hugo aha at pos_left
    with slide

    h "You're absolutely right about that, Deputy!"

    # ---------- STEP 1: GIVEN ----------

    h "Step 1: Identifying the Given Variables. First things first, let's list down everything we know from the problem."

    $ ch2_m1 = ""
    $ ch2_V1 = ""
    $ ch2_m2 = ""
    $ ch2_V2 = ""

    jump ch2_given_try


label ch2_given_try:

    call screen given_input_2

    $ g1 = q_has(ch2_m1, 150)
    $ g2 = q_has(ch2_V1, 4)
    $ g3 = q_has(ch2_m2, 50)
    $ g4 = q_has(ch2_V2, 0) and str(ch2_V2).strip() != ""

    if g1 and g2 and g3 and g4:

        show hugo excited at pos_left
        with slide

        h "That's right! Our rolling supply cart (m₁) is 150 kilograms, and its initial velocity (v₁i) is 4.0 meters per second."
        h "The stationary timber cart (m₂) is 50 kilograms. Since it's parked and standing still before the hit, its initial velocity (v₂i) is 0 meters per second."

    else:

        show hugo serious at pos_left
        with slide

        if not g1:
            h "Check m₁. What's the mass of the rolling supply cart?"
        elif not g2:
            h "Check v₁i. How fast is the supply cart rolling at the start?"
        elif not g3:
            h "Check m₂. What's the mass of the timber cart?"
        else:
            h "Check v₂i. The timber cart is standing still before the hit."

        $ renpy.notify("Try again!")

        jump ch2_given_try

    # ---------- STEP 2: EQUATION ----------

    h "Step 2: Setting Up the Conservation Equation. Now, let's write down our conservation of linear momentum equation for a perfectly inelastic collision. Do you still remember it, Kid?"

    jump ch2_q_equation


label ch2_q_equation:

    $ answer = renpy.call_screen(
        "mcq_screen",
        title="STEP 2 - SETTING UP THE EQUATION",
        problem="Which equation represents the conservation of linear momentum for a perfectly inelastic collision?",
        choices=[
            "m₁v₁i + m₂v₂i = m₁v₁f + m₂v₂f",
            "m₁v₁i + m₂v₂i = (m₁ + m₂)vf",
            "m₁v₁i − m₂v₂i = (m₁ + m₂)vf"
        ],
        hint_text="The carts stick together, so their masses add up into one combined mass with one shared final velocity."
    )

    if answer == "m₁v₁i + m₂v₂i = (m₁ + m₂)vf":

        show ye h at pos_right
        with slide

        n "m₁v₁i + m₂v₂i = (m₁ + m₂)vf"

        show hugo excited at pos_left
        with dissolve

        h "That's right!"

    else:

        show hugo serious at pos_left
        with dissolve

        h "Not quite. The carts stick together, so what happens to their masses on the right side?"

        $ renpy.notify("Try again! You can use the hint.")

        jump ch2_q_equation

    show screen formula_card(
        "PERFECTLY INELASTIC COLLISION",
        "m₁v₁i + m₂v₂i = (m₁ + m₂)vf",
        "v₁i, v₂i = initial velocities\nvf = final velocity of both carts"
    )

    h "Look at the right side of that equation. Because the two carts stick together after the collision, their masses add up into a single combined mass, (m₁ + m₂), and they share one final velocity, vf."

    h "Let's plug our numbers into the left side first to find the total initial momentum of our system."

    hide screen formula_card

    show screen solution_card("STEP 2 - TOTAL INITIAL MOMENTUM", [
        "p initial = m₁v₁i + m₂v₂i",
        "p initial = (150 kg)(4.0 m/s) + (50 kg)(0 m/s)"
    ])

    h "Since anything multiplied by zero is zero, that second term drops right out! That leaves us with:"

    show screen solution_card("STEP 2 - TOTAL INITIAL MOMENTUM", [
        "p initial = m₁v₁i + m₂v₂i",
        "p initial = (150 kg)(4.0 m/s) + (50 kg)(0 m/s)",
        "p initial = 600 kg·m/s + 0",
        "p initial = 600 kg·m/s"
    ])

    h "Total initial momentum is 600 kilogram meters per second."

    # ---------- STEP 3: SOLVING ----------

    h "Step 3: Solving for Final Velocity. Now we set our total initial momentum equal to our final combined momentum."

    show screen solution_card("STEP 3 - SOLVING FOR FINAL VELOCITY", [
        "m₁v₁i + m₂v₂i = (m₁ + m₂)vf",
        "600 kg·m/s = (150 kg + 50 kg)vf"
    ])

    h "Add those masses together:"

    show screen solution_card("STEP 3 - SOLVING FOR FINAL VELOCITY", [
        "m₁v₁i + m₂v₂i = (m₁ + m₂)vf",
        "600 kg·m/s = (150 kg + 50 kg)vf",
        "600 kg·m/s = (200 kg)vf"
    ])

    h "Your turn, Deputy. Isolate vf."

    $ ch2_vf = ""
    $ guesa_solution_drawn = False
    $ scratch_pad.clear()

    jump ch2_solve_try


label ch2_solve_try:

    call screen solve_input_2

    if q_has(ch2_vf, 3) and str(ch2_vf).strip() != "":

        show ye capehand at pos_right
        with slide

        show screen solution_card("FINAL VELOCITY", [
            "600 kg·m/s = (200 kg)vf",
            "vf = (600 kg·m/s) ÷ (200 kg)",
            "vf = +3.0 m/s"
        ])

        n "To isolate our final velocity, we divide both sides by the total combined mass of 200 kg."

        show hugo excited at pos_left
        with slide

        hide screen solution_card

        h "Look at that! Before the collision, the supply cart was hauling at 4.0 meters per second. But by locking it to the stationary cart, you increased the total mass of the system while keeping total momentum conserved."

        show ye capehand at pos_right
        with slide

        n "This means the final velocity drops down to a safe 3.0 meters per second, giving the wooden wedge enough time to bring the whole system to a complete stop! I get it now..."

    else:

        show hugo lala at pos_left
        with slide

        h "Not quite. Divide the total initial momentum by the combined mass. Check your numbers and your units."

        $ renpy.notify("Try again! You can use the hint.")

        jump ch2_solve_try

    hide screen solution_card

    # ---------- ANIMATION ----------

    $ renpy.movie_cutscene("videos/chapter_2.webm")

    scene black
    with fade

    # ---------- AFTER THE SAVE ----------

    scene chap2
    with fade

    show hugo happy at pos_left
    show ye ohno at pos_right
    with slide

    n "I... can't believe I pulled it off."

    h "See? I knew you had it in you, Deputy."

    n "It was just luck. You pretty much did all the work without breaking a sweat."

    show hugo hah at pos_left
    with dissolve

    h "You credit me too much, Kid. Take a good look at yourself for once. I couldn't have stopped the cart without your help."

    show hugo aha at pos_left
    with dissolve

    h "You've pretty much mastered the fundamentals, but it's clear that you still lack something..."

    n "Strength? Speed? Intellect? Yeah, don't have 'em."

    h "Trust. That's what you lack. Trust in how physics works and, most importantly... trust in yourself."

    show ye b at pos_right
    with dissolve

    n "...Now that doesn't make any sense."

    show hugo smile at pos_left
    with dissolve

    h "It'll make sense someday. For now, take a break, Deputy. You did a great job on your first day."

    hide hugo
    hide ye
    scene black
    with fade

    $ persistent.ch2_activity_unlocked = True

    call screen chapter_card("CHAPTER 2 COMPLETE")

    jump chapter2_activity


# ==========================================
# CHAPTER 2 - ACTIVITY (QUEST 2)
# ==========================================

label chapter2_activity:

    $ safe_autosave()

    $ q2_tries = 0
    $ guesa_solution_drawn = False
    $ scratch_pad.clear()
    $ q2_m1 = ""
    $ q2_u1 = ""
    $ q2_m2 = ""
    $ q2_u2 = ""
    $ q2_unknown = ""
    $ q2_equation = ""
    $ q2_vf = ""
    $ q2_ke = ""

    scene chap2
    with fade

    show hugo serious at pos_left
    show ye stand at pos_right
    with dissolve

    h "One more, Deputy. An enforcer is waiting at the depot platform to ambush you. Let's see if you can handle him."

    jump chapter2_activity_try


label chapter2_activity_try:

    call screen quest_form("q2")

    $ g_ok = q2_check_given()
    $ u_ok = q2_check_unknown()
    $ e_ok = q2_check_equation()
    $ s_ok = q_solution_ok()
    $ v_ok = q_vf_ok(q2_vf, 3.13)
    $ k_ok = q_ke_ok(q2_ke, 1150)

    if g_ok and u_ok and e_ok and s_ok and v_ok and k_ok:

        $ persistent.chapter_3_unlocked = True

        show hugo excited at pos_left
        show ye capehand at pos_right
        with slide

        show screen solution_card("QUEST 2 - SOLUTION", [
            "m₁v₁i + m₂v₂i = (m₁ + m₂)vf",
            "(85 kg)(+7.0 m/s) + (105 kg)(0 m/s) = (85 kg + 105 kg)vf",
            "595 kg·m/s = (190 kg)vf",
            "vf = 595 kg·m/s ÷ 190 kg = +3.13 m/s",
            "KEi = ½(85 kg)(7.0 m/s)² = 2,082.5 J",
            "KEf = ½(190 kg)(3.13 m/s)² ≈ 931 J",
            "KE lost = KEi − KEf ≈ 1.15 × 10³ J"
        ])

        n "We move together at +3.13 m/s, and about 1.15 × 10³ J was lost."

        h "Spot on, Deputy! You both move in your original direction, and the lost energy turns into heat and sound."

        hide screen solution_card

        jump chapter2_activity_end

    else:

        $ q2_tries += 1

        show hugo serious at pos_left
        show ye ugh at pos_right
        with slide

        if not g_ok:
            h "Check your Given. Both masses, both initial velocities. The enforcer is at rest."
        elif not u_ok:
            h "There are two unknowns here. Name both."
        elif not e_ok:
            h "Your equation is off. They move together after the tackle, so use (m₁ + m₂)vf."
        elif not s_ok:
            h "Show me your solution on the whiteboard, then press DONE."
        elif not v_ok:
            h "Check your final velocity. Divide the total momentum by the combined mass. Include the unit."
        else:
            h "Check your energy lost. It's KEi minus KEf, in joules."

        $ renpy.notify("Try again!")

        jump chapter2_activity_try


label chapter2_activity_end:

    hide hugo
    hide ye
    scene black
    with fade

    call screen chapter_card("CHAPTER 2 ACTIVITY COMPLETE")

    jump chapter3_dialogue


# ==========================================
# CHAPTER 3 - STEEL FOR STEEL
# ==========================================

label chapter3_dialogue:

    $ safe_autosave()

    call screen chapter_title(3, "STEEL FOR STEEL", "images/chap3.png")

    scene chap3
    with fade

    stop music fadeout 1.0
    play music "audio/w1.ogg" fadein 1.0

    "A narrow canyon outpost outside Oakhaven. High stone walls flank a dusty trail."

    show ye normaly at pos_right
    with dissolve

    "(The Player sits on a wooden crate, nursing a cup of coffee and studying the notebook, still turning over Hugo's words about trust.)"

    n "Trust in myself... easy for him to say. It's one thing to lock down a slow wooden cart, but what happens when something actually hits hard?"

    # play sound "audio/rumble.ogg"
    "(Suddenly, a deep, grinding metallic rumble echoes down the narrow canyon walls, shaking loose dust and pebbles from the cliffs above.)"

    show ye ohno at pos_right
    with slide

    n "Hugo! You there? We've got movement in the upper canyon pass!"

    show hugo lala at pos_left
    with slide

    h "I hear it, Deputy. Looks like Selena Colm's gang didn't like losing that supply cart in town. They're striking back. What do you see coming down the trail?"

    show ye weh at pos_right
    with slide

    n "It's an iron-plated safe! And it's rolling down fast, heading straight toward the town's barricade! If it hits the wood, it's going to smash right through!"

    show hugo lala at pos_left
    with slide

    h "An iron safe won't crumple or stick like that wooden wagon, Kid. It's solid steel. What kind of impact happens when two hard, rigid objects collide without losing energy to heat or bending?"

    show ye b at pos_right
    with slide

    n "An elastic collision!"

    show ye what at pos_right
    with slide

    n "But a wooden barricade won't hold it. It'll splinter into toothpicks...!"

    show hugo smirk at pos_left
    with slide

    h "Good thing you're standing next to the spring-loaded defense gate. You've got an identical stationary steel barrier right on the track waiting for it. Remember what I said about trust? Time to trust physics."

    show ye fight at pos_right
    with slide

    n "Alright... equal masses, elastic collision, total momentum and kinetic energy conserved. Let's see how hard this thing bounces!"

    jump chapter3_lesson


# ==========================================
# CHAPTER 3 - LESSON PROPER: ELASTIC COLLISIONS
# ==========================================

label chapter3_lesson:

    show hugo happy at pos_left
    show ye fight at pos_right
    with slide

    show screen formula_card(
        "GIVEN",
        "m₁ = 50 kg     v₁i = +6.0 m/s\nm₂ = 50 kg     v₂i = 0 m/s",
        "Find the final velocities v₁f and v₂f."
    )

    "Selena Colm's gang is rolling an iron-plated safe with a mass of 50 kg down a narrow canyon path at an initial velocity of +6.0 m/s toward the Player's barricade."
    "To deflect it without letting it break through, the Player uses a spring-loaded gate mechanism to trigger an ideal one-dimensional elastic collision with an identical stationary steel barrier of mass 50 kg."
    "What are the final velocities of the iron-plated safe and the barrier after this elastic collision?"

    hide screen formula_card

    h "Alright, Deputy. That safe isn't sticking like the supply cart last time. It's built heavy, solid, and completely unyielding. Let's break down the math behind this."

    h "In physics, when two objects collide and bounce off each other while conserving both total momentum and total kinetic energy, what do we call it?"

    jump ch3_q_type


label ch3_q_type:

    $ answer = renpy.call_screen(
        "mcq_screen",
        title="TYPE OF COLLISION",
        problem="Two objects collide and bounce off each other, conserving both total momentum and total kinetic energy. What do we call this?",
        choices=[
            "Inelastic Collision",
            "Perfectly Inelastic Collision",
            "Elastic Collision"
        ],
        hint_text="Both momentum AND kinetic energy are conserved, so nothing is lost to heat or bending."
    )

    if answer == "Elastic Collision":

        show ye capehand at pos_right
        with slide

        n "Elastic collision."

        show hugo excited at pos_left
        with slide

        h "Spot on! Let's remember what the rules tell us for an elastic collision: both linear momentum and kinetic energy are conserved."
        h "When you have an ideal one-dimensional elastic collision between two objects of identical mass, something brilliant happens."

    else:

        show hugo mad at pos_left
        with slide

        h "Not quite. Which type keeps both momentum and kinetic energy?"

        $ renpy.notify("Try again! You can use the hint.")

        jump ch3_q_type

    # ---------- STEP 1: GIVEN ----------

    show hugo happy at pos_left
    with slide

    h "First things first: let's list down everything we know from the problem."

    $ ch3_m1 = ""
    $ ch3_u1 = ""
    $ ch3_m2 = ""
    $ ch3_u2 = ""

    jump ch3_given_try


label ch3_given_try:

    call screen given_input_3

    $ g1 = q_has(ch3_m1, 50)
    $ g2 = q_has(ch3_u1, 6)
    $ g3 = q_has(ch3_m2, 50)
    $ g4 = q_has(ch3_u2, 0) and str(ch3_u2).strip() != ""

    if g1 and g2 and g3 and g4:

        show hugo excited at pos_left
        with slide

        h "That's right! The rolling iron safe (m₁) is 50 kilograms, and its initial velocity (v₁i) is +6.0 meters per second."
        h "The stationary steel barrier (m₂) is also 50 kilograms. It's standing still, so its initial velocity (v₂i) is 0 meters per second."

    else:

        show hugo lala at pos_left
        with slide

        if not g1:
            h "Check m₁. What's the mass of the rolling iron safe?"
        elif not g2:
            h "Check v₁i. How fast is the safe rolling at the start? Mind the sign."
        elif not g3:
            h "Check m₂. What's the mass of the steel barrier?"
        else:
            h "Check v₂i. The barrier is standing still before the hit."

        $ renpy.notify("Try again!")

        jump ch3_given_try

    # ---------- STEP 2: EQUATIONS ----------

    h "Now, let's write down our conservation equations. For an elastic collision, we balance both momentum and kinetic energy:"

    show screen formula_card(
        "CONSERVATION OF MOMENTUM",
        "m₁v₁i + m₂v₂i = m₁v₁f + m₂v₂f",
        ""
    )

    h "That's the first one. Momentum."

    show screen formula_card(
        "CONSERVATION OF KINETIC ENERGY",
        "½m₁v₁i² + ½m₂v₂i²\n= ½m₁v₁f² + ½m₂v₂f²",
        ""
    )

    h "And the second one. Kinetic energy."

    hide screen formula_card

    h "Do you remember what happens to the velocities when the masses are completely identical (m₁ = m₂)?"

    jump ch3_q_equal


label ch3_q_equal:

    $ answer = renpy.call_screen(
        "mcq_screen",
        title="STEP 2 - IDENTICAL MASSES",
        problem="In an elastic collision, what happens to the velocities when the two masses are identical (m₁ = m₂)?",
        choices=[
            "They stick together and share one velocity.",
            "They bounce backward at double speed.",
            "They completely exchange their velocities."
        ],
        hint_text="Think of a moving ball hitting an identical ball at rest. What does each one do afterward?"
    )

    if answer == "They completely exchange their velocities.":

        show ye stand at pos_right
        with slide

        n "They completely exchange their velocities."

        show hugo excited at pos_left
        with dissolve

        h "You've got it! The moving object transfers 100 percent of its momentum and kinetic energy to the stationary one."

    else:

        show hugo serious at pos_left
        with dissolve

        h "Not quite. Sticking together is the perfectly inelastic case. Try again."

        $ renpy.notify("Try again! You can use the hint.")

        jump ch3_q_equal

    # ---------- STEP 3: SOLVING ----------

    h "Step 3: Solving for Final Velocities."

    show ye shys at pos_right
    with slide

    n "So this means I don't have to go through intense solving just to find their final velocities?"

    show hugo sher at pos_left
    with slide

    h "That's right! But then again, this only works when both objects have equal masses. Otherwise, we'll have to take into account these formulas:"

    show screen formula_card(
        "ELASTIC COLLISION, m₂ AT REST",
        "v₁f = (m₁ − m₂)/(m₁ + m₂) · v₁i",
        "v₂f = 2m₁/(m₁ + m₂) · v₁i"
    )

    show ye normaly at pos_right
    with slide

    n "Alright... So since mass 1 and mass 2 are both 50 kg, the incoming safe stops completely, and the stationary barrier takes its speed!"

    hide screen formula_card

    show screen solution_card("FINAL VELOCITIES", [
        "v₁f = (50 − 50)/(50 + 50) · (+6.0 m/s) = 0 m/s",
        "v₂f = 2(50)/(50 + 50) · (+6.0 m/s) = +6.0 m/s"
    ])

    n "Final velocity of the iron safe (v₁f): 0 m/s. Final velocity of the steel barrier (v₂f): +6.0 m/s."

    hide screen solution_card

    show ye fight at pos_right
    with slide

    n "Here it comes."

    # ---------- ANIMATION ----------

    $ renpy.movie_cutscene("videos/chapter_3.webm")

    scene black
    with fade

    "(The safe slams into the steel barrier and stops dead in its tracks. The barrier surges forward at +6.0 m/s, taking all of the safe's speed.)"

    # ---------- AFTER THE COLLISION ----------

    scene chap3
    with fade

    show ye weh at pos_center
    with slide

    n "It... it actually worked? The safe stopped dead in its tracks..."

    show hugo excited at pos_left
    show ye weh at pos_right
    with slide

    h "Now that's what I call collision. You timed the gate to the split second like a true hero."

    show ye shys at pos_right
    with slide

    n "..."

    show hugo sad at pos_left
    with slide

    h "Something wrong, Deputy?"

    show ye h at pos_right
    with slide

    n "Realistically speaking... I'm no hero, Hugo. Every time something goes right, I feel like I'm just faking it until the next disaster proves I don't belong here."

    show hugo serious at pos_left
    with slide

    h "Listen, Kid. You aren't faking anything. Look at that safe. Look at that barricade. You read the situation, you made the call, and you held your ground when every instinct told you to run."
    h "The math was just a tool. You were the one who had the courage to use it."

    show ye what at pos_right
    with slide

    n "You really mean that... don't you?"

    show hugo aha at pos_left
    with slide

    h "I don't waste breath on hollow praise, Kid. I put you out here because I saw what you're capable of, even when you refuse to see it yourself."
    h "Fighting crime isn't about being fearless or flawless. It's about stepping up even when your hands are shaking. And today, you stepped up."

    show ye shys at pos_right
    with slide

    n "..."

    show ye smile at pos_right
    with slide

    n "Thank you, Hugo."

    show hugo smile at pos_left
    with slide

    h "That's what I'm here for, Deputy. Now stand tall, will ya? You just saved the whole canyon pass. Let's head back to town, coffee's on me."

    show ye ugh at pos_right
    with slide

    n "You're just saying that to bribe me into answering more worksheets..."

    hide hugo
    hide ye
    scene black
    with fade

    $ persistent.ch3_activity_unlocked = True

    call screen chapter_card("CHAPTER 3 COMPLETE")

    jump chapter3_activity


# ==========================================
# CHAPTER 3 - ACTIVITY (QUEST 3)
# ==========================================

label chapter3_activity:

    $ safe_autosave()

    $ q3_tries = 0
    $ guesa_solution_drawn = False
    $ scratch_pad.clear()
    $ q3_m1 = ""
    $ q3_u1 = ""
    $ q3_m2 = ""
    $ q3_u2 = ""
    $ q3_unknown = ""
    $ q3_equation = ""
    $ q3_v1f = ""
    $ q3_v2f = ""
    $ q3_dir = ""

    scene chap3
    with fade

    show hugo hufo at pos_left
    show ye stand at pos_right
    with dissolve

    h "Not so fast, Deputy. Colm's outlaws are making a run for it from the Silver Spur Mine, and they're sending a loaded mine cart your way."
    h "The rail switch is yours. This time, the masses aren't equal. Show me what you've got."

    jump chapter3_activity_try


label chapter3_activity_try:

    call screen quest_form("q3")

    $ g_ok = q3_check_given()
    $ u_ok = q3_check_unknown()
    $ e_ok = q3_check_equation()
    $ s_ok = q_solution_ok()
    $ a1_ok = q3_check_v1f(q3_v1f)
    $ a2_ok = q3_check_v2f(q3_v2f)
    $ d_ok = q3_check_dir(q3_dir)

    if g_ok and u_ok and e_ok and s_ok and a1_ok and a2_ok and d_ok:

        $ persistent.chapter_4_unlocked = True

        show hugo excited at pos_left
        show ye capehand at pos_right
        with slide

        show screen solution_card("QUEST 3 - SOLUTION", [
            "v₁f = (m₁ − m₂)/(m₁ + m₂) · v₁i",
            "v₁f = (80 − 40)/(80 + 40) · (+8.0 m/s) = +2.67 m/s",
            "v₂f = 2m₁/(m₁ + m₂) · v₁i",
            "v₂f = 2(80)/(80 + 40) · (+8.0 m/s) = +10.67 m/s",
            "v₁f is positive, so the loot cart keeps moving forward"
        ])

        n "The loot cart keeps moving forward."

        h "Spot on, Deputy! The heavier cart can't bounce back off a lighter one. It slows down, and the switch-cart takes off ahead of it."

        hide screen solution_card

        jump chapter3_activity_end

    else:

        $ q3_tries += 1

        show hugo lala at pos_left
        show ye ugh at pos_right
        with slide

        if not g_ok:
            h "Check your Given. Both masses, both initial velocities. The switch-cart is stationary."
        elif not u_ok:
            h "You need the final velocities of both carts and the direction of the loot cart. Name them."
        elif not e_ok:
            h "Your equation is off. The masses are different, so use the formulas for v₁f and v₂f."
        elif not s_ok:
            h "Show me your solution on the whiteboard, then press DONE."
        elif not a1_ok:
            h "Check the loot cart's final velocity. Subtract the masses on top, add them on the bottom, then multiply by v₁i."
        elif not a2_ok:
            h "Check the switch-cart's final velocity. Use 2m₁ over (m₁ + m₂), then multiply by v₁i."
        else:
            h "Look at the sign of v₁f. Does it keep going the same way, or does it reverse?"

        $ renpy.notify("Try again!")

        jump chapter3_activity_try


label chapter3_activity_end:

    hide hugo
    hide ye
    scene black
    with fade

    call screen chapter_card("CHAPTER 3 ACTIVITY COMPLETE")

    jump chapter4_dialogue


# ==========================================
# CHAPTER 4 - ONE WAY OR ANOTHER
# ==========================================

label chapter4_dialogue:

    $ safe_autosave()

    call screen chapter_title(4, "ONE WAY OR ANOTHER", "images/chap4_1.png")

    # ---------- SCENE 1: SELENA'S OFFICE ----------

    scene chap4_1
    with fade

    stop music fadeout 1.0
    play music "audio/w1.ogg" fadein 1.0

    show selena 2 at pos_center
    with slide

    s "He really thinks he can hide behind textbooks?"
    s "And sending a child to do all his dirty work?... You're no better than me, Hugo Vector."

    show selena 1 at pos_center
    with dissolve

    s "Out here on the frontier, power is the only law that survives. My strength is the very reason Hugo walks with a limp."
    s "I crushed his leg once, and I won't hesitate to break what's left of him."

    show selena 9 at pos_center
    with dissolve

    s "Enjoy your little victory, Deputy. It won't be long before you're broken on the dirt right beside him."

    hide selena
    scene black
    with fade

    # ---------- SCENE 2: SHERIFF'S OFFICE ----------

    scene intro1
    with fade

    show hugo sad at pos_left
    show ye h at pos_right
    with slide

    n "Hugo... back in the canyon, you said Selena Colm was responsible for your leg. Is that... is that why you stopped?"

    show hugo serious at pos_left
    with slide

    h "Selena believes brute force is the only rule that governs the world, Deputy. She thinks breaking a man's leg breaks his spirit. But force without direction is just mindless chaos."

    show ye fight at pos_right
    with slide

    n "I won't let her hurt anyone else in Oakhaven. I promise you that."

    show hugo hufo at pos_left
    with slide

    h "Hold that thought, Kid. Look at the main track!"

    # play sound "audio/crash_warning.ogg"
    "(Panicked yelling. Heavy iron wheels screech down the track.)"

    hide hugo
    hide ye
    scene black
    with fade

    # ---------- SCENE 3: THE RAILWAY ----------

    scene chap4_2
    with fade

    "(Hugo and the Deputy rush out of the office and toward the main track.)"

    show hugo serious at pos_left
    show ye whamn at pos_right
    with slide

    n "Selena’s men left a stationary supply cart loaded with wooden crates right on our track! Our 120-kg railway cart is moving at +5.0 m/s and heading straight for it!"

    h "Look at those emergency coupling hooks! On impact, they're going to latch tight and force both carts to move as one!"

    show ye weh at pos_right
    with slide

    n "Th-the momentum is strictly linear along the track! I can try to figure out the final speed once the carts stick together—and how much kinetic energy gets totally wrecked in the collision!"

    show hugo lala at pos_left
    with slide

    h "Calculate it fast, Kid—we need to know how fast this whole mess is rolling toward the station!"

    show ye goe at pos_right
    with slide

    n "I've got this, Hugo!"

    show screen formula_card(
        "PERFECTLY INELASTIC COLLISION",
        "m₁v₁i + m₂v₂i = (m₁ + m₂)vf",
        "Kinetic energy lost = KEi − KEf, where KE = ½mv²"
    )

    jump chapter4_quest4


# ==========================================
# QUEST 4
# ==========================================

label chapter4_quest4:

    $ safe_autosave()

    $ q4_tries = 0
    $ guesa_solution_drawn = False
    $ scratch_pad.clear()
    $ q4_m1 = ""
    $ q4_u1 = ""
    $ q4_m2 = ""
    $ q4_u2 = ""
    $ q4_unknown = ""
    $ q4_equation = ""
    $ q4_vf = ""
    $ q4_ke = ""

    jump chapter4_quest4_try


label chapter4_quest4_try:

    call screen quest_form("q4")

    $ g_ok = q4_check_given()
    $ u_ok = q_unknown_ok(q4_unknown)
    $ e_ok = q45_check_equation(q4_equation)
    $ s_ok = q_solution_ok()
    $ v_ok = q_vf_ok(q4_vf, 3.0)
    $ k_ok = q_ke_ok(q4_ke, 600)

    if g_ok and u_ok and e_ok and s_ok and v_ok and k_ok:

        hide screen formula_card

        show hugo excited at pos_left
        show ye capehand at pos_right
        with slide

        show screen solution_card("QUEST 4 - SOLUTION", [
            "m₁v₁i + m₂v₂i = (m₁ + m₂)vf",
            "(120 kg)(+5.0 m/s) + (80 kg)(0 m/s) = (120 kg + 80 kg)vf",
            "600 kg·m/s = (200 kg)vf",
            "vf = 600 kg·m/s ÷ 200 kg = +3.0 m/s",
            "KEi = ½(120 kg)(5.0 m/s)² = 1,500 J",
            "KEf = ½(200 kg)(3.0 m/s)² = 900 J",
            "KE lost = KEi − KEf = 600 J"
        ])

        h "That's the math, Kid. Now brace yourself, here it comes!"

        hide screen solution_card

        jump chapter4_quest4_cutscene

    else:

        $ q4_tries += 1

        show hugo smirk at pos_left
        show ye ugh at pos_right
        with slide

        if not g_ok:
            h "Check your Given. Both masses, both initial velocities. The crate cart is stationary."
        elif not u_ok:
            h "There are two unknowns here. Name both."
        elif not e_ok:
            h "Your equation is off. The carts lock together, so use (m₁ + m₂)vf."
        elif not s_ok:
            h "Show me your solution on the whiteboard, then press DONE."
        elif not v_ok:
            h "Check your final velocity. Divide the total momentum by the combined mass. Include the unit."
        else:
            h "Check your energy lost. It's KEi minus KEf, in joules."

        $ renpy.notify("Try again!")

        jump chapter4_quest4_try

    scene black
    with fade

    "(A deafening CRASH echoes across the junction as steel twists into steel.)"

    scene chap4_2
    with fade

    show hugo serious at pos_left
    show ye whamn at pos_right
    with slide

    n "Wait... look at the math. The final velocity is only +3.0 m/s!"

    h "Only 3 meters per second?"

    show ye smile at pos_right
    with slide

    n "Yeah! That's... that's like a jogging pace. Because the total mass jumped when they locked together, the speed dropped sharply. They're not barreling out of control—they're just coasting to a gentle crawl!"

    "(The grinding screech of the wheels fades into a slow, rhythmic clack-clack as the combined carts safely roll to a halt near the platform.)"

    show hugo smirk at pos_left
    with slide

    h "Phew... well I'll be. They aren't going to level the station after all. Good calculations, Kid. You just saved Oakhaven a whole lot of expensive property damage."

    n "Don't ever scare me like that again. Let's go check the crates–"

    hide hugo
    hide ye

    "(Suddenly, a cold, heavy silence falls over the crossroads. The lingering dust clears, revealing a tall, shadowed figure standing atop the twisted wreckage of the supply cart.)"

    # play sound "audio/revolver_click.ogg"
    "(The sharp, echoing click of a heavy iron hammer being pulled back on a revolver.)"

    show selena 5 at pos_center
    with slide

    s "Hm. I should’ve loaded more explosives onto that front cart... or perhaps made the railway cart move much faster than a paltry five meters per second."

    s "But no matter. A minor miscalculation on my part, yet it changes nothing. You were so busy playing hero with a pencil and scratch paper that you completely walked right into my trap."

    hide selena

    show hugo mad at pos_left
    show ye what at pos_right
    with slide

    n "Selena Colm...!"

    h "Selena. It's been a long time."

    hide hugo
    hide ye

    show selena 10 at pos_center
    with slide

    s "Too long, Vector. I see you brought a new apprentice to break. But this ends here. Tonight, Oakhaven will finally be mine, and you..."

    show selena 5 at pos_center
    with dissolve

    s "You won’t be standing by the time the sun rises."

    hide selena

    show hugo lala at pos_left
    show ye fight at pos_right
    with slide

    n "We won’t let that happen, not on my watch!"

    hide hugo
    hide ye
    scene black
    with fade

    $ persistent.ch4_activity_unlocked = True

    jump chapter4_final


# ==========================================
# THE FINAL STAND OF OAKHAVEN
# ==========================================

label chapter4_final:

    $ safe_autosave()

    $ renpy.movie_cutscene("videos/chap5_intro.webm")

    stop music fadeout 1.0
    play music "audio/w3.ogg" fadein 1.0

    scene chap5
    with fade

    "(Oakhaven’s main street, moments after Selena Colm’s arrival at the crossroads. Smoke rises from damaged buildings as outlaws surround the sheriff’s office. The townspeople scramble for shelter while the distant sound of gunfire echoes through the streets.)"

    # play sound "audio/chaos.ogg"
    "(Horses whinny, boots pound against wooden floors, and gunshots echo in the distance.)"

    show selena 1 at pos_center
    with slide

    s "Look around you, Deputy. Your precious town is falling apart, and you’re still standing there pretending you can save it."

    hide selena

    show ye fight at pos_left
    with slide

    n "This town has survived worse than you."

    show selena 2 at pos_right
    with slide

    s "Has it? Your sheriff can barely walk without that cane, and you’re nothing but a clerk who learned a few equations."

    show ye what at pos_left
    with slide

    n "Maybe. But I’m not the one who’s afraid of losing."

    show selena 4 at pos_right
    with slide

    s "Afraid? You have no idea what fear is."

    hide ye
    hide selena

    "(Selena raises her revolver, but Hugo fires a warning shot into the dirt between them.)"

    show ye fight at pos_left
    show hugo lala at pos_right
    with slide

    h "That’s enough, Selena. If you want to settle this, you’ll have to get through me first."

    hide ye
    hide hugo

    show selena 9 at pos_center
    with slide

    s "You? You can hardly stand, Vector."

    hide selena

    show hugo smirk at pos_center
    with slide

    h "Good thing standing isn’t the only thing a sheriff needs to do."

    hide hugo

    "(Selena smirks and signals her men.)"

    show selena 10 at pos_center
    with slide

    s "Take the office. Bring the whole building down if you have to!"

    hide selena

    "(She mounts her horse and retreats behind the advancing outlaws.)"

    # play sound "audio/wheels_rattle.ogg"
    "(Heavy iron wheels rattle violently against the tracks.)"

    show ye weh at pos_left
    show hugo hufo at pos_right
    with slide

    n "Hugo! Selena’s heavy supply cart is barreling straight toward the escape track!"

    h "I see her, Deputy! If that 180-kg cart reaches the main line at 6.0 m/s eastward, she’s gone for good—and taking Oakhaven’s resources with her."

    n "There’s no time to stop her cart manually!"

    show hugo serious at pos_right
    with slide

    h "Then don’t try to stop it—block it! Look up ahead on the track line. See that defensive cart?"

    show ye ohno at pos_left
    with slide

    n "A stationary cart! Quick, help me toss these heavy sandbags in—if I can load it up to exactly 120 kg, those heavy-duty auto-couplers are gonna lock on impact! They’ll link together and move straight down the track as one single unit!"

    n "But... Sheriff, what if 120 kg isn’t enough weight to slow it down? What if the supply cart carries enough momentum to break right through our barriers anyway? If I mess up the speed or energy calculations... we lose her and wreck the station!"

    show hugo lala at pos_right
    with slide

    h "Look at me, Kid. You’ve handled every physics dilemma thrown at you without flinching. Trust in physics... trust yourself. You’ve got this."

    show ye fight at pos_left
    with slide

    n "...You’re right. I can’t back out now! Let’s find their final speed, calculate the energy lost in the crunch, and lock down their exact direction. Let’s finish this!"

    hide ye
    hide hugo

    "It's time to use what you've learned to finally put an end to Selena Colm's crimes and save the town. Prove that you're truly deserving to be the next Sheriff of Oakhaven!"

    jump chapter4_quest5


# ==========================================
# QUEST 5
# ==========================================

label chapter4_quest5:

    $ safe_autosave()

    $ q5_tries = 0
    $ guesa_solution_drawn = False
    $ scratch_pad.clear()
    $ q5_m1 = ""
    $ q5_u1 = ""
    $ q5_m2 = ""
    $ q5_u2 = ""
    $ q5_unknown = ""
    $ q5_equation = ""
    $ q5_vf = ""
    $ q5_ke = ""
    $ q5_dir = ""

    jump chapter4_quest5_try


label chapter4_quest5_try:

    call screen quest_form("q5")

    $ g_ok = q5_check_given()
    $ u_ok = q_unknown_ok(q5_unknown, need_dir=True)
    $ e_ok = q45_check_equation(q5_equation)
    $ s_ok = q_solution_ok()
    $ v_ok = q_vf_ok(q5_vf, 3.6)
    $ k_ok = q_ke_ok(q5_ke, 1296)
    $ d_ok = q5_check_dir(q5_dir)

    if g_ok and u_ok and e_ok and s_ok and v_ok and k_ok and d_ok:

        $ persistent.chapter_5_unlocked = True

        show hugo excited at pos_right
        show ye capehand at pos_left
        with slide

        show screen solution_card("QUEST 5 - SOLUTION", [
            "m₁v₁i + m₂v₂i = (m₁ + m₂)vf",
            "(180 kg)(+6.0 m/s) + (120 kg)(0 m/s) = (180 kg + 120 kg)vf",
            "1,080 kg·m/s = (300 kg)vf",
            "vf = 1,080 kg·m/s ÷ 300 kg = +3.6 m/s",
            "KEi = ½(180 kg)(6.0 m/s)² = 3,240 J",
            "KEf = ½(300 kg)(3.6 m/s)² = 1,944 J",
            "KE lost = KEi − KEf = 1,296 J",
            "vf is positive, so the carts move east"
        ])

        n "The carts move east at +3.6 m/s, and 1,296 J was lost."

        h "Spot on, Deputy! Both carts lock together and keep rolling east, only slower."

        hide screen solution_card

        jump chapter4_finale

    else:

        $ q5_tries += 1

        show hugo smirk at pos_right
        show ye ugh at pos_left
        with slide

        if not g_ok:
            h "Check your Given. Both masses, both initial velocities. The defensive cart is stationary."
        elif not u_ok:
            h "Three unknowns this time: the final velocity, the energy lost, and the direction. Name them."
        elif not e_ok:
            h "Your equation is off. The carts lock together, so use (m₁ + m₂)vf."
        elif not s_ok:
            h "Show me your solution on the whiteboard, then press DONE."
        elif not v_ok:
            h "Check your final velocity. Divide the total momentum by the combined mass. Include the unit."
        elif not k_ok:
            h "Check your energy lost. It's KEi minus KEf, in joules."
        else:
            h "Check the direction. Look at the sign of vf. Which way does the combined cart move?"

        $ renpy.notify("Try again!")

        jump chapter4_quest5_try


# ==========================================
# FINAL CONFRONTATION
# ==========================================

label chapter4_finale:

    hide hugo
    hide ye

    $ renpy.movie_cutscene("videos/chapter_5.webm")

    scene black
    with fade

    # play music "audio/tense.ogg" fadeout 1.0 fadein 1.0

    scene chap5
    with fade

    "(The central town square. Selena Colm stands beside her horse as the last of her outlaws retreat into the surrounding alleys. The Player approaches, with Hugo following behind.)"

    show selena 4 at pos_left
    show ye normaly at pos_right
    with slide

    s "You stopped my wagon. Congratulations."

    show selena 10 at pos_left
    show ye what at pos_right
    with dissolve

    s "Do you honestly think one clever trick makes you a sheriff?"

    n "No. But protecting the people who depend on me is a pretty good place to start."

    s "You’re still just a clerk playing dress-up."

    show ye hips at pos_right
    show selena 5 at pos_left
    with slide

    n "Maybe that’s what you see. But I know what I can do now, and I don’t need you to agree with me."

    s "You think your little equations can save you every time?"

    show ye smile at pos_right
    with slide

    n "No. Physics doesn’t promise that everything will go my way. It gives me a way to understand what’s happening and make better decisions."

    hide ye
    hide selena

    show hugo smile at pos_center
    with slide

    h "Sounds like someone finally learned the lesson."

    hide hugo

    show selena 8 at pos_center
    with slide

    s "Enough!"

    hide selena

    "(Selena reaches for her revolver, but the remaining townspeople step out from the mercantile and surrounding buildings. The Player holds their ground as the town marshal and deputies surround Selena’s gang.)"

    show ye h at pos_left
    show hugo hufo at pos_right
    with slide

    n "It’s over, Selena. Put the weapon down."

    hide hugo
    hide ye

    show selena 7 at pos_center
    with slide

    s "This isn’t the end, Vector."

    hide selena

    show ye h at pos_left
    show hugo hufo at pos_right
    with slide

    h "Maybe not. But today, it is."

    hide hugo
    hide ye

    "(The clink of handcuffs echoes across the square.)"

    jump mastery_checkpoint


# ==========================================
# MASTERY CHECKPOINT - SHERIFF LICENSURE EXAMINATION
# ==========================================

label mastery_checkpoint:

    $ safe_autosave()

    scene black
    with fade

    "Congratulations! You've saved the town once again!"

    "Before officially becoming the next Sheriff of Oakhaven, take the official Sheriff Licensure Examination!"

    "Directions: Read each question carefully and choose the best answer."

    $ mastery_score = 0
    $ mastery_review = []
    $ mastery_i = 0

    while mastery_i < len(mastery_questions):

        python:
            m_item = mastery_questions[mastery_i]
            m_pick = renpy.call_screen(
                "mastery_question",
                mastery_i + 1,
                len(mastery_questions),
                m_item["q"],
                m_item["choices"]
            )

            m_ok = (m_pick == m_item["answer"])
            if m_ok:
                mastery_score += 1

            mastery_review.append({
                "q": m_item["q"],
                "picked": m_item["choices"][m_pick],
                "correct": m_item["choices"][m_item["answer"]],
                "ok": m_ok
            })

            mastery_i += 1

    call screen mastery_results(mastery_score, len(mastery_questions), mastery_review)

    jump chapter5_completion


# ==========================================
# COMPLETION SCENE
# ==========================================

label chapter5_completion:

    scene intro1
    with fade

    "Later that evening, the town gathers outside the sheriff’s office. The damaged rail system is being repaired, and the townspeople begin clearing the debris from the street."

    "Hugo places a sheriff’s badge on the desk in front of the Player."

    show hugo happy at pos_right
    show ye sasageyo at pos_left
    with slide

    n "What’s this?"

    h "I’d say you’ve earned it."

    n "Hugo... I still have a lot to learn. I can’t promise I’ll always make the right decision."

    show hugo ehe at pos_right
    show ye smile at pos_left
    with slide

    h "Neither can I. That’s why we keep learning."

    play music "audio/badge.ogg" fadeout 1.0 fadein 1.0

    hide hugo
    hide ye

    scene c5_1
    with fade

    "(The Player picks up the badge and studies it.)"

    n "I used to think being a sheriff meant being fearless, strong, and always knowing what to do."

    h "And now?"

    n "Now I think it means being willing to act even when you’re uncertain, learning from your mistakes, and trusting the people who stand beside you."

    h "Not bad for a former clerk."

    n "Former clerk?"

    h "You didn’t think I was going to let you return to filing paperwork all day, did you?"

    n "I knew there was a catch. I should’ve negotiated for better working hours."

    scene c5_2
    with dissolve

    h "Welcome to the job, Sheriff."

    n "Thank you, Hugo."

    n "{i}Momentum. Collisions. Conservation. I used to think that they were nothing more than equations in a notebook. But somewhere along the way, I learned that understanding the world is only part of the challenge.{/i}"

    n "{i}The other part is trusting myself enough to face it.{/i}"

    h "Come on, Deputy. Coffee’s getting cold."

    n "You’re paying, right?"

    h "Don’t push your luck, Kid."

    scene black
    with fade

    call screen chapter_card("CHAPTER 4 COMPLETE")

    jump chapter5_timeskip


# ==========================================
# TIMESKIP
# ==========================================

label chapter5_timeskip:

    play music "audio/timeskip.ogg" fadeout 1.0 fadein 1.0

    scene black
    with fade

    # play sound "audio/wheels_boardwalk.ogg"
    "(Wooden wheels clatter on the boardwalk. People chatter, then a little boy trips, dropping his toy train right at the Player’s boots.)"

    n "Careful there, little guy. Keep an eye on your speed."

    scene c5_3
    with fade

    kid "Woah... Sheriff [persistent.player_name]! You’re the one who saved Oakhaven from Selena! Wow... I can’t believe I get to see you in person! You’re so awesome!"

    n "It was just a little math and momentum, kid."

    kid "Still, it was really cool! I wish I were strong too! Strong enough to protect the town from crimes..."

    n "You don’t have to be the strongest in order to protect. If you understand the motions around you, then that’s more than enough."

    kid "Can I really be a great sheriff like you?"

    n "I’m sure. Trust in physics, and more importantly, trust in yourself."

    kid "Alright! I’m gonna study hard and be a hero just like you!"

    n "I’ll be waiting for it then."

    stop music fadeout 2.0

    scene black
    with fade

    call screen chapter_card("THE END", "Thank you for playing Oakhaven")

    return