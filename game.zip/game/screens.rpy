﻿# BUTTON STYLES
# ==========================================

style box_button:
    xsize 380
    ysize 64
    xalign 0.5
    idle_background Fixed(Solid("#D9A441", xysize=(380, 64)), Solid("#3B2314", xysize=(374, 58), align=(0.5, 0.5)), xysize=(380, 64))
    hover_background Fixed(Solid("#FFD27A", xysize=(380, 64)), Solid("#6B4423", xysize=(374, 58), align=(0.5, 0.5)), xysize=(380, 64))
    insensitive_background Fixed(Solid("#6B5A45", xysize=(380, 64)), Solid("#2A1A10", xysize=(374, 58), align=(0.5, 0.5)), xysize=(380, 64))

style box_button_text:
    xalign 0.5
    yalign 0.5
    size 26
    color "#FFFFFF"
    hover_color "#FFD27A"
    insensitive_color "#8A7A66"

style pt_choice:
    xsize 900
    ysize 60
    xalign 0.5
    background Fixed(Solid("#D9A441", xysize=(900, 60)), Solid("#3B2314", xysize=(894, 54), align=(0.5, 0.5)), xysize=(900, 60))
    hover_background Fixed(Solid("#FFD27A", xysize=(900, 60)), Solid("#6B4423", xysize=(894, 54), align=(0.5, 0.5)), xysize=(900, 60))
    selected_background Solid("#D9A441")
    selected_hover_background Solid("#FFD27A")

style pt_choice_text:
    xalign 0.5
    yalign 0.5
    size 24
    color "#FFFFFF"
    hover_color "#FFD27A"
    selected_color "#2A1A10"
    selected_hover_color "#2A1A10"

style pt_continue:
    xsize 520
    ysize 64
    xalign 0.5
    background Fixed(Solid("#D9A441", xysize=(520, 64)), Solid("#3B2314", xysize=(514, 58), align=(0.5, 0.5)), xysize=(520, 64))
    hover_background Fixed(Solid("#FFD27A", xysize=(520, 64)), Solid("#6B4423", xysize=(514, 58), align=(0.5, 0.5)), xysize=(520, 64))

style pt_continue_text:
    xalign 0.5
    yalign 0.5
    size 26
    color "#FFFFFF"
    hover_color "#FFD27A"

style wb_tool_button:
    background "#3A3028"
    hover_background "#65503A"
    selected_background "#D9A441"
    padding (12, 8)

style wb_tool_button_text:
    color "#FFFFFF"
    hover_color "#D9A441"
    selected_color "#2A1A10"
    size 20

style say_dialogue:
    size 30
    color "#F5EBD8"
    line_spacing 6
    xfill True

style say_label:
    size 34
    bold False

style quick_button:
    xsize 150
    ysize 44
    background "#120C09D9"
    hover_background "#3B2314"

style quick_button_text:
    size 22
    color "#E8D5B5"
    hover_color "#FFD27A"
    xalign 0.5
    yalign 0.5

style guesa_label:
    size 22
    bold True
    color "#D9A441"

style guesa2_input:
    size 24
    color "#FFF1DD"
    xfill True
    ysize 40


# ==========================================
# REUSABLE LOOPING TRAIN BACKGROUND
# ==========================================

screen train_background():

    add Movie(
        play="images/trainloop.webm",
        size=(config.screen_width, config.screen_height)
    )


# ==========================================
# MAIN MENU
# ==========================================

screen main_menu():

    tag menu

    use train_background

    frame:
        xalign 0.98
        yalign 0.5
        xsize 500
        ysize 800
        background "#101010B8"
        padding (45, 40)

        vbox:
            spacing 22
            xfill True
            yalign 0.5

            add "images/logo.png":
                xalign 0.5
                xsize 400
                ysize 180
                fit "contain"

            # With a save: asks Continue or Start from the beginning
            textbutton "START":
                action If(latest_save() is not None, Show("start_choice"), Start())
                style "box_button"

            textbutton "CHAPTERS":
                action ShowMenu("chapter_select")
                style "box_button"

            textbutton "CUSTOMIZE NAME":
                action ShowMenu("name_customization")
                style "box_button"

            textbutton "SETTINGS":
                action ShowMenu("preferences")
                style "box_button"

            textbutton "CREDITS":
                action ShowMenu("credits_screen")
                style "box_button"

            null height 10

            text "A JOURNEY THROUGH OAKHAVEN":
                size 15
                color "#D9A441"
                xalign 0.5


screen start_choice():

    modal True
    zorder 300

    add Solid("#000000B8")

    key "game_menu" action Hide("start_choice")

    frame:
        xalign 0.5
        yalign 0.5
        xsize 600
        background "#2A1A10"
        padding (40, 35)

        vbox:
            spacing 20
            xfill True

style sc_button:
    xsize 500
    ysize 64
    xalign 0.5
    padding (0, 0, 0, 0)
    idle_background Fixed(Solid("#D9A441", xysize=(500, 64)), Solid("#3B2314", xysize=(494, 58), align=(0.5, 0.5)), xysize=(500, 64))
    hover_background Fixed(Solid("#FFD27A", xysize=(500, 64)), Solid("#6B4423", xysize=(494, 58), align=(0.5, 0.5)), xysize=(500, 64))
    insensitive_background Fixed(Solid("#6B5A45", xysize=(500, 64)), Solid("#2A1A10", xysize=(494, 58), align=(0.5, 0.5)), xysize=(500, 64))

style sc_button_text:
    xalign 0.5
    yalign 0.5
    text_align 0.5
    size 24
    color "#FFFFFF"
    hover_color "#FFD27A"
    insensitive_color "#8A7A66"


screen start_choice():

    modal True
    zorder 300

    add Solid("#000000B8")

    key "game_menu" action Hide("start_choice")

    frame:
        xalign 0.5
        yalign 0.5
        xsize 620
        background "#2A1A10"
        padding (60, 40)

        vbox:
            spacing 20
            xfill True

            text "START GAME":
                size 36
                bold True
                color "#D9A441"
                xalign 0.5

            null height 6

            textbutton "CONTINUE":
                style "sc_button"
                action Function(continue_game)

            textbutton "START FROM THE BEGINNING":
                style "sc_button"
                action Start()

            textbutton "BACK":
                style "sc_button"
                action Hide("start_choice")


# ==========================================
# CUSTOMIZE PLAYER NAME
# ==========================================

screen name_customization():

    tag menu

    use train_background

    frame:
        xalign 0.5
        yalign 0.5
        xsize 700
        background "#101010E8"
        padding (50, 45)

        vbox:
            spacing 25
            xfill True

            text "CUSTOMIZE YOUR NAME":
                size 36
                color "#D9A441"
                xalign 0.5

            text "Enter the name you want characters to use.":
                size 20
                xalign 0.5
                text_align 0.5

            input:
                value FieldInputValue(persistent, "player_name")
                length 20
                copypaste True
                xalign 0.5
                size 30

            text "Current name: [persistent.player_name]":
                size 22
                xalign 0.5

            textbutton "SAVE AND RETURN":
                action Return()
                xalign 0.5
                text_size 25

            textbutton "BACK":
                action Return()
                xalign 0.5
                text_size 22


# ==========================================
# CHAPTER SELECT
# ==========================================

screen chapter_select():

    tag menu

    use train_background

    key "game_menu" action Return()

    frame:
        xalign 0.5
        yalign 0.5
        xsize 800
        background "#101010E8"
        padding (45, 40)

        vbox:
            spacing 18
            xfill True

            text "SELECT CHAPTER":
                size 42
                bold True
                color "#D9A441"
                xalign 0.5

            null height 10

            for num, title in chapter_list:
                if chapter_open(num):
                    textbutton ("CHAPTER " + str(num) + " - " + title):
                        action Start("replay_entry_" + str(num))
                        xsize 700
                        ysize 64
                        xalign 0.5
                        background "#3A2418"
                        hover_background "#513522"
                        text_size 26
                        text_color "#FFFFFF"
                        text_hover_color "#D9A441"
                        text_xalign 0.5
                        text_yalign 0.5
                else:
                    textbutton ("CHAPTER " + str(num) + " - LOCKED"):
                        action NullAction()
                        sensitive False
                        xsize 700
                        ysize 64
                        xalign 0.5
                        background "#2A1A10"
                        text_size 26
                        text_insensitive_color "#6B5A45"
                        text_xalign 0.5
                        text_yalign 0.5

            null height 10

            textbutton "BACK":
                action Return()
                xalign 0.5
                text_size 25
                text_color "#FFFFFF"
                text_hover_color "#D9A441"


# ==========================================
# SETTINGS
# ==========================================

screen setting_bar(label, pref):
    text label size 22 color "#F5EBD8"
    bar:
        value Preference(pref)
        xfill True
        ysize 26
        left_bar Solid("#D9A441")
        right_bar Solid("#3B2314")
        thumb Solid("#FFFFFF", xysize=(14, 26))
        thumb_offset 7


screen preferences():

    tag menu

    if main_menu:
        use train_background
    else:
        add Solid("#000000B0")

    key "game_menu" action Return()

    frame:
        xalign 0.5
        yalign 0.4
        xsize 800
        background "#101010E8"
        padding (45, 30)

        vbox:
            spacing 10
            xfill True

            text "SETTINGS" size 42 color "#D9A441" xalign 0.5

            text "DISPLAY" size 24 color "#D9A441"
            hbox:
                spacing 30
                xalign 0.5
                textbutton "WINDOWED":
                    action Preference("display", "window")
                    text_size 22
                    text_color "#FFFFFF"
                    text_hover_color "#D9A441"
                    text_selected_color "#D9A441"
                textbutton "FULLSCREEN":
                    action Preference("display", "fullscreen")
                    text_size 22
                    text_color "#FFFFFF"
                    text_hover_color "#D9A441"
                    text_selected_color "#D9A441"

            text "QUALITY" size 24 color "#D9A441"
            hbox:
                spacing 30
                xalign 0.5
                textbutton "LOW":
                    action [SetField(persistent, "quality", "low"),
                            Preference("gl framerate", 30),
                            Preference("gl powersave", True)]
                    text_size 22
                    text_color "#FFFFFF"
                    text_hover_color "#D9A441"
                    text_selected_color "#D9A441"
                textbutton "HIGH":
                    action [SetField(persistent, "quality", "high"),
                            Preference("gl framerate", None),
                            Preference("gl powersave", False)]
                    text_size 22
                    text_color "#FFFFFF"
                    text_hover_color "#D9A441"
                    text_selected_color "#D9A441"

            use setting_bar("BACKGROUND MUSIC", "music volume")
            use setting_bar("TEXT SPEED", "text speed")

    hbox:
        xalign 0.5
        yalign 0.95
        spacing 20

        textbutton "BACK":
            action Return()
            style "box_button"
            xsize 280

        if not main_menu:
            textbutton "MAIN MENU":
                action Show("leave_to_menu")
                style "box_button"
                xsize 280


# ==========================================
# SAVE PROGRESS
# ==========================================

screen save_progress():

    tag menu

    add Solid("#000000B0")

    key "game_menu" action Return()

    frame:
        xalign 0.5
        yalign 0.5
        xsize 800
        background "#101010E8"
        padding (45, 35)

        vbox:
            spacing 14
            xfill True

            text "SAVE PROGRESS":
                size 42
                bold True
                color "#D9A441"
                xalign 0.5

            null height 6

            for i in range(1, 6):
                button:
                    xsize 700
                    ysize 70
                    xalign 0.5
                    background "#3A2418"
                    hover_background "#513522"
            for i in range(1, 6):
                button:
                    xsize 700
                    ysize 70
                    xalign 0.5
                    background "#3A2418"
                    hover_background "#513522"
                    action [FileSave(i, confirm=False), MainMenu(confirm=False)]

                    hbox:
                        spacing 25
                        yalign 0.5
                        xalign 0.5

                        text ("SLOT " + str(i)):
                            size 24
                            bold True
                            color "#D9A441"

                        text FileTime(i, format="%b %d, %Y  %H:%M", empty="Empty slot"):
                            size 22
                            color "#F5EBD8"

            null height 6

            textbutton "BACK":
                action Return()
                xalign 0.5
                text_size 25
                text_color "#FFFFFF"
                text_hover_color "#D9A441"


# ==========================================
# CONFIRM (used by Main Menu, etc.)
# ==========================================

screen confirm(message, yes_action, no_action):

    modal True
    zorder 400

    add Solid("#000000B8")

    frame:
        xalign 0.5
        yalign 0.5
        xsize 800
        background "#2A1A10"
        padding (40, 30)

        vbox:
            spacing 25
            xfill True

            text message:
                size 28
                color "#F5EBD8"
                xalign 0.5
                text_align 0.5

            hbox:
                xalign 0.5
                spacing 30

                textbutton "YES":
                    action yes_action
                    style "box_button"
                    xsize 250

                textbutton "NO":
                    action [no_action, Show("quick_menu")]
                    style "box_button"
                    xsize 250


# ==========================================
# CREDITS
# ==========================================
# h = heading, l = role + name, s = small note, g = gap

define credits_data = [
    ("l", "Game Director", "Shane M. Valdez"),

    ("h", "DESIGN"),
    ("l", "Game Design", "Faith Christa M. Dagdag"),
    ("l", "Narrative Design", "Diana Joyce M. Gomez"),

    ("h", "PROGRAMMING"),
    ("l", "Lead Programmer", "Mary Esther Nicole J. Fandagani"),

    ("h", "ART & ANIMATION"),
    ("l", "Concept Artist", "Diana Joyce M. Gomez"),
    ("l", "3D Environment Artist", "Faith Christa M. Dagdag"),
    ("l", "Character Artist", "Diana Joyce M. Gomez"),
    ("l", "Lead Animator", "Faith Christa M. Dagdag"),
    ("l", "UI/UX Designer", "Mary Esther Nicole J. Fandagani"),

    ("h", "MODULE AND CONTENT"),
    ("l", "Topic Content", "Shane M. Valdez"),
    ("l", "Learning Material", "Shane M. Valdez"),

    ("h", "CAST / VOICE TALENT"),
    ("l", "Sheriff Hugo Vector", "Elijah Bernard Refuerzo"),
    ("l", "Narrator", "Diana Joyce M. Gomez"),

    ("h", "QUALITY ASSURANCE"),
    ("l", "Experts", ""),

    ("h", "SPECIAL THANKS"),
    ("l", "Capstone Project Teacher", "Ma'am Corazon A. Adrales"),
    ("l", "General Physics 1 Teacher", "Sir Angelo Louis Dorosan"),

    ("h", "TOOLS, SOFTWARE & ASSETS"),
    ("l", "Game Engine", "Ren'Py Visual Novel Engine"),
    ("s", "Visual Novel Engine © 2004-2026 Tom Rothamel. All rights reserved."),
    ("l", "Asset Illustration", "Ibis Paint X"),
    ("l", "Video Editing & Trailers", "CapCut"),

    ("h", "EXTERNAL ASSETS & AUDIO"),
    ("l", "Background Imagery", "Sourced via Creative Commons / Public Domain Libraries"),
    ("l", "Audio & Sound Effects", "Sourced from Copyright-Free YouTube Creators and Libraries"),

    ("g", ""),
    ("f", "© 2026 ALL RIGHTS RESERVED."),
]

screen credits_screen():

    tag menu

    use train_background

    key "game_menu" action Return()

    frame:
        xalign 0.5
        yalign 0.45
        xsize 900
        ysize 900
        background "#101010E8"
        padding (45, 35)

        vbox:
            spacing 15
            xsize 810

            text "PHYSIX QUEST":
                size 46
                bold True
                color "#D9A441"
                xalign 0.5

            text "By Group 1":
                size 24
                color "#F5EBD8"
                xalign 0.5

            hbox:
                spacing 10
                xsize 810

                viewport:
                    id "credits_vp"
                    xsize 780
                    ysize 680
                    mousewheel True
                    draggable True

                    vbox:
                        xsize 780
                        spacing 14

                        for item in credits_data:

                            if item[0] == "h":
                                null height 14
                                text item[1]:
                                    size 30
                                    bold True
                                    color "#D9A441"
                                    xalign 0.5
                                    text_align 0.5

                            elif item[0] == "l":
                                vbox:
                                    xalign 0.5
                                    spacing 2
                                    text item[1]:
                                        size 20
                                        color "#D9A441"
                                        xalign 0.5
                                        text_align 0.5
                                    if item[2] != "":
                                        text item[2]:
                                            size 26
                                            color "#FFFFFF"
                                            xalign 0.5
                                            text_align 0.5
                                            xmaximum 740

                            elif item[0] == "s":
                                text item[1]:
                                    size 18
                                    color "#CCCCCC"
                                    xalign 0.5
                                    text_align 0.5
                                    xmaximum 740

                            elif item[0] == "f":
                                text item[1]:
                                    size 22
                                    color "#D9A441"
                                    xalign 0.5
                                    text_align 0.5

                            else:
                                null height 25

                vbar:
                    value YScrollValue("credits_vp")
                    xsize 16
                    ysize 680
                    top_bar Solid("#3B2314")
                    bottom_bar Solid("#3B2314")
                    thumb Solid("#D9A441", xysize=(16, 70))
                    thumb_offset 35

            textbutton "BACK":
                action Return()
                xalign 0.5
                text_size 25
                text_color "#FFFFFF"
                text_hover_color "#D9A441"


# ==========================================
# CHAPTER TITLE PAGE (all chapters)
# ==========================================

screen chapter_title(num, name, bg):

    modal True
    zorder 100

    add bg

    add "#00000088"

    vbox:
        xalign 0.5
        yalign 0.5
        spacing 25

        text "OAKHAVEN":
            size 30
            color "#D9A441"
            xalign 0.5

        text ("CHAPTER " + str(num)):
            size 64
            color "#FFFFFF"
            xalign 0.5

        text name:
            size 28
            color "#D9A441"
            xalign 0.5

        textbutton "CONTINUE":
            action Return()
            xalign 0.5
            text_size 30
            text_color "#FFFFFF"
            text_hover_color "#D9A441"


# ==========================================
# CHAPTER CARD (centered title)
# ==========================================

screen chapter_card(title, subtitle=""):

    modal True
    zorder 300

    add Solid("#000000")

    vbox:
        xalign 0.5
        yalign 0.5
        spacing 20

        text "OAKHAVEN":
            size 30
            color "#D9A441"
            xalign 0.5

        text title:
            size 64
            color "#FFFFFF"
            xalign 0.5
            text_align 0.5

        if subtitle != "":
            text subtitle:
                size 28
                color "#D9A441"
                xalign 0.5
                text_align 0.5

    key "dismiss" action Return()
    timer 3.5 action Return()


# ==========================================
# DIALOGUE BOX + QUICK MENU
# ==========================================

screen say(who, what):

    style_prefix "say"

    window:
        id "window"
        xpos 170
        yalign 0.97
        xsize 1570
        ysize 230
        background Solid("#CDB48A")
        padding (2, 2)

        window:
            xfill True
            yfill True
            background Solid("#120C09E6")
            padding (60, 40)

            text what:
                id "what"

        if who is not None:

            window:
                id "namebox"
                xpos 30
                ypos -52
                background Solid("#CDB48A")
                padding (2, 2)

                window:
                    background Solid("#2A1A10")
                    padding (45, 8)

                    text who:
                        id "who"


screen quick_menu():

    zorder 100

    vbox:
        xalign 1.0
        yalign 0.93
        spacing 6

        textbutton "Back" action Rollback() style "quick_button"
        textbutton "Auto" action Preference("auto-forward", "toggle") style "quick_button" selected_background "#6B4423"
        textbutton "Settings" action ShowMenu("preferences") style "quick_button"


screen corner_logo():

    zorder 150

    add "images/logo_small.png":
        xalign 0.0
        yalign 0.02
        xsize 160
        ysize 80
        fit "contain"


# ==========================================
# WHITEBOARD
# ==========================================

init python:
    import pygame

    class Whiteboard(renpy.Displayable):

        def __init__(self, w, h, **kwargs):
            super(Whiteboard, self).__init__(**kwargs)
            self.w = w
            self.h = h
            self.strokes = []
            self.current = None
            self.color = "#111111"
            self.width = 4

        def set_pen(self, color, width):
            self.color = color
            self.width = width
            renpy.redraw(self, 0)

        def undo(self):
            if self.strokes:
                self.strokes.pop()
            renpy.redraw(self, 0)

        def clear(self):
            self.strokes = []
            self.current = None
            renpy.redraw(self, 0)

        def render(self, width, height, st, at):
            r = renpy.Render(self.w, self.h)
            c = r.canvas()

            c.rect("#FFFFFF", (0, 0, self.w, self.h))

            for color, wd, pts in self.strokes:
                if len(pts) > 1:
                    c.lines(color, False, pts, wd)

                for p in pts:
                    c.circle(color, p, max(1, wd // 2))

            return r

        def event(self, ev, x, y, st):

            inside = (0 <= x < self.w and 0 <= y < self.h)

            if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1 and inside:

                self.current = (self.color, self.width, [(x, y)])
                self.strokes.append(self.current)
                renpy.redraw(self, 0)
                raise renpy.IgnoreEvent()

            elif ev.type == pygame.MOUSEMOTION and self.current is not None:

                if inside:
                    self.current[2].append((x, y))
                    renpy.redraw(self, 0)
                    raise renpy.IgnoreEvent()

            elif ev.type == pygame.MOUSEBUTTONUP and ev.button == 1:

                if self.current is not None:
                    self.current = None
                    renpy.redraw(self, 0)
                    raise renpy.IgnoreEvent()

            return None

    scratch_pad = Whiteboard(1100, 430)


screen whiteboard_screen(problem="Solve the problem on the board."):

    modal True
    zorder 300

    default board = scratch_pad
    default active_tool = "BLACK"

    add Solid("#101522")

    frame:
        xalign 0.5
        yalign 0.5
        xsize min(1450, config.screen_width - 40)
        ysize min(650, config.screen_height - 40)
        background "#202B3B"
        padding (25, 20)

        vbox:
            spacing 15
            xfill True
            yfill True

            hbox:
                xfill True
                spacing 20

                text "WHITEBOARD":
                    size 30
                    bold True
                    color "#D9A441"
                    yalign 0.5

                null width 20

                textbutton "BACK":
                    action Hide("whiteboard_screen")
                    text_size 22

                textbutton "DONE - RETURN TO GUESA":
                    action [
                        SetVariable("guesa_solution_drawn", True),
                        Hide("whiteboard_screen")
                    ]
                    text_size 22

            text problem:
                size 22
                color "#FFFFFF"
                xfill True

            hbox:
                spacing 18
                xfill True
                yfill True

                frame:
                    xsize 190
                    background "#101522"
                    padding (12, 12)

                    vbox:
                        spacing 10

                        text "TOOLS":
                            size 22
                            color "#D9A441"
                            bold True

                        textbutton "BLACK":
                            style "wb_tool_button"
                            text_style "wb_tool_button_text"
                            selected (active_tool == "BLACK")
                            action [
                                SetScreenVariable("active_tool", "BLACK"),
                                Function(board.set_pen, "#111111", 4)
                            ]

                        textbutton "RED":
                            style "wb_tool_button"
                            text_style "wb_tool_button_text"
                            selected (active_tool == "RED")
                            action [
                                SetScreenVariable("active_tool", "RED"),
                                Function(board.set_pen, "#CC2222", 4)
                            ]

                        textbutton "BLUE":
                            style "wb_tool_button"
                            text_style "wb_tool_button_text"
                            selected (active_tool == "BLUE")
                            action [
                                SetScreenVariable("active_tool", "BLUE"),
                                Function(board.set_pen, "#2255CC", 4)
                            ]

                        textbutton "ERASER":
                            style "wb_tool_button"
                            text_style "wb_tool_button_text"
                            selected (active_tool == "ERASER")
                            action [
                                SetScreenVariable("active_tool", "ERASER"),
                                Function(board.set_pen, "#FFFFFF", 20)
                            ]

                        null height 10

                        textbutton "UNDO":
                            style "wb_tool_button"
                            text_style "wb_tool_button_text"
                            action Function(board.undo)

                        textbutton "CLEAR":
                            style "wb_tool_button"
                            text_style "wb_tool_button_text"
                            action Function(board.clear)

                frame:
                    background "#D9A441"
                    padding (4, 4)
                    xfill True
                    yfill True

                    add board:
                        xalign 0.5
                        yalign 0.5


# ==========================================
# MULTIPLE CHOICE SCREEN
# ==========================================

screen mcq_screen(title, problem, choices, hint_text):

    modal True
    zorder 100

    default show_hint = False

    add Solid("#000000B8")

    frame:
        xalign 0.5
        yalign 0.5
        xsize 1000
        background "#2A1A10"
        padding (35, 25)

        vbox:
            xfill True
            spacing 18

            text title:
                size 30
                color "#D9A441"

            text problem:
                size 25
                color "#F5EBD8"
                xfill True

            text "Choose the correct answer:":
                size 22
                color "#FFFFFF"

            vbox:
                xalign 0.5
                spacing 12

                for choice in choices:
                    textbutton choice:
                        style "pt_choice"
                        action Return(choice)

            hbox:
                xalign 0.5
                spacing 15

                textbutton "HINT":
                    action ToggleScreenVariable("show_hint")
                    xsize 300
                    ysize 60
                    background "#3A2418"
                    hover_background "#513522"
                    text_color "#FFFFFF"
                    text_hover_color "#D9A441"
                    text_size 24
                    text_xalign 0.5
                    text_yalign 0.5

                textbutton "WHITEBOARD":
                    action Show("whiteboard_screen", problem=problem)
                    xsize 300
                    ysize 60
                    background "#3A2418"
                    hover_background "#513522"
                    text_color "#FFFFFF"
                    text_hover_color "#D9A441"
                    text_size 24
                    text_xalign 0.5
                    text_yalign 0.5

            if show_hint:
                frame:
                    xfill True
                    background "#F5EBD8"
                    padding (15, 10)
                    text hint_text:
                        color "#2A1A10"
                        size 20
                        xfill True
                        text_align 0.5


# ==========================================
# FORMULA CARD
# ==========================================

screen formula_card(title, formula, note=""):

    zorder 50

    frame:
        xalign 0.5
        yalign 0.08
        xsize 900
        background "#D9A441"
        padding (2, 2)

        frame:
            xfill True
            background "#2A1A10"
            padding (30, 22)

            vbox:
                xfill True
                spacing 14

                text title:
                    size 26
                    bold True
                    color "#D9A441"
                    xalign 0.5
                    text_align 0.5

                text formula:
                    size 36
                    bold True
                    color "#FFFFFF"
                    xalign 0.5
                    text_align 0.5
                    xmaximum 820

                if note:
                    text note:
                        size 22
                        color "#F5EBD8"
                        xalign 0.5
                        text_align 0.5
                        xmaximum 820


# ==========================================
# KNOWLEDGE CHECKPOINT + MASTERY SCREENS
# ==========================================

screen pretest_question(num, total, question, choices):

    modal True
    zorder 100

    default picked = None

    add Solid("#000000D0")

    frame:
        xalign 0.5
        yalign 0.5
        xsize 1000
        background "#2A1A10"
        padding (40, 30)

        vbox:
            xfill True
            spacing 18

            text "KNOWLEDGE CHECKPOINT [num]/[total]":
                size 28
                color "#D9A441"

            text question:
                size 28
                color "#F5EBD8"
                xfill True

            null height 5

            for i, c in enumerate(choices):
                textbutton c:
                    style "pt_choice"
                    selected (picked == i)
                    action SetScreenVariable("picked", i)

            null height 10

            if num == total:
                textbutton "SUBMIT":
                    style "box_button"
                    sensitive (picked is not None)
                    action Return(picked)
            else:
                textbutton "NEXT":
                    style "box_button"
                    sensitive (picked is not None)
                    action Return(picked)


screen pretest_results(score, total, review):

    modal True
    zorder 100

    default idx = 0

    add Solid("#000000E0")

    frame:
        xalign 0.5
        yalign 0.5
        background "#D9A441"
        padding (2, 2)

        frame:
            xsize 1100
            background "#2A1A10"
            padding (45, 35)

            $ it = review[idx]

            vbox:
                xfill True
                spacing 18

                text "KNOWLEDGE CHECKPOINT RESULTS":
                    size 36
                    color "#D9A441"
                    xalign 0.5

                text "Your score: [score] / [total]":
                    size 32
                    bold True
                    color "#FFD27A"
                    xalign 0.5

                null height 10

                text ("Question " + str(idx + 1) + " of " + str(total)):
                    size 24
                    color "#D9A441"

                text (it["q"]):
                    size 28
                    bold True
                    color "#F5EBD8"
                    xsize 1000

                if it["ok"]:
                    text ("Your answer: " + it["picked"] + "  -  CORRECT"):
                        size 24
                        color "#7BD88F"
                        xsize 1000
                else:
                    text ("Your answer: " + it["picked"] + "  -  WRONG"):
                        size 24
                        color "#FF7B7B"
                        xsize 1000
                    text ("Correct answer: " + it["correct"]):
                        size 24
                        color "#7BD88F"
                        xsize 1000

                null height 10

                if idx < total - 1:
                    textbutton "NEXT":
                        style "pt_continue"
                        action SetScreenVariable("idx", idx + 1)
                else:
                    textbutton "CONTINUE TO CHAPTER 1":
                        style "pt_continue"
                        action Return()


screen mastery_question(num, total, question, choices):

    modal True
    zorder 100

    default picked = None

    add Solid("#000000D0")

    frame:
        xalign 0.5
        yalign 0.5
        xsize 1000
        background "#2A1A10"
        padding (40, 30)

        vbox:
            xfill True
            spacing 18

            text "MASTERY CHECKPOINT [num]/[total]":
                size 28
                color "#D9A441"

            text question:
                size 28
                color "#F5EBD8"
                xfill True

            null height 5

            for i, c in enumerate(choices):
                textbutton c:
                    style "pt_choice"
                    selected (picked == i)
                    action SetScreenVariable("picked", i)

            null height 10

            if num == total:
                textbutton "SUBMIT":
                    style "box_button"
                    sensitive (picked is not None)
                    action Return(picked)
            else:
                textbutton "NEXT":
                    style "box_button"
                    sensitive (picked is not None)
                    action Return(picked)


screen mastery_results(score, total, review):

    modal True
    zorder 100

    default idx = 0

    add Solid("#000000E0")

    frame:
        xalign 0.5
        yalign 0.5
        background "#D9A441"
        padding (2, 2)

        frame:
            xsize 1100
            background "#2A1A10"
            padding (45, 35)

            $ it = review[idx]

            vbox:
                xfill True
                spacing 18

                text "MASTERY CHECKPOINT RESULTS":
                    size 36
                    color "#D9A441"
                    xalign 0.5

                text "Your score: [score] / [total]":
                    size 32
                    bold True
                    color "#FFD27A"
                    xalign 0.5

                null height 10

                text ("Question " + str(idx + 1) + " of " + str(total)):
                    size 24
                    color "#D9A441"

                text (it["q"]):
                    size 28
                    bold True
                    color "#F5EBD8"
                    xsize 1000

                if it["ok"]:
                    text ("Your answer: " + it["picked"] + "  -  CORRECT"):
                        size 24
                        color "#7BD88F"
                        xsize 1000
                else:
                    text ("Your answer: " + it["picked"] + "  -  WRONG"):
                        size 24
                        color "#FF7B7B"
                        xsize 1000
                    text ("Correct answer: " + it["correct"]):
                        size 24
                        color "#7BD88F"
                        xsize 1000

                null height 10

                if idx < total - 1:
                    textbutton "NEXT":
                        style "pt_continue"
                        action SetScreenVariable("idx", idx + 1)
                else:
                    textbutton "CONTINUE":
                        style "pt_continue"
                        action Return()


# ==========================================
# INPUT FIELD (used by every G.U.E.S.A. form)
# ==========================================

screen guesa2_field(title, var_name, current, hint):
    default iv = VariableInputValue(var_name, default=False)

    vbox:
        spacing 6
        xsize 660
        text title style "guesa_label"

        button:
            xsize 660
            ysize 56
            background "#D9A441"
            padding (2, 2)
            action iv.Enable()

            frame:
                xfill True
                yfill True
                background "#24180F"
                padding (14, 8)

                fixed:
                    xfill True
                    ysize 40

                    if current == "":
                        text hint:
                            size 20
                            italic True
                            color "#8A7A66"
                            yalign 0.5

                    input:
                        value iv
                        style "guesa2_input"
                        length 60
                        yalign 0.5


# ==========================================
# QUEST DATA (Quests 1.2 to 5)
# Each field is (label, variable name, placeholder).
# A field with variable None shows the whiteboard note (S - SOLUTION).
# ==========================================

init python:

    quest_defs = {

        "q12": {
            "title": "QUEST 1.2 - G.U.E.S.A.",
            "psize": 22,
            "problem": "An outlaw stands at rest on a getaway train car holding a 4.5 kg double-barrel shotgun. He fires a single 0.015 kg bullet straight forward at +280 m/s. Calculate the shotgun's recoil velocity immediately after the shot.",
            "left": [
                ("G - GIVEN: MASS OF SHOTGUN", "guesa2_mass_gun", "Mass with unit"),
                ("G - GIVEN: MASS OF BULLET", "guesa2_mass_bullet", "Mass with unit"),
                ("G - GIVEN: BULLET VELOCITY", "guesa2_vel_bullet", "Velocity with sign and unit"),
                ("U - UNKNOWN", "guesa2_unknown", "What are we solving for?"),
            ],
            "right": [
                ("E - EQUATION", "guesa2_equation", "Write the equation"),
                ("S - SOLUTION", None, None),
                ("A - ANSWER (with sign)", "guesa2_answer", "Value with sign and unit"),
            ],
            "hints": [
                "HINT 1: Initial velocity is 0 since it is at rest.",
                "HINT 2: 0 = m₁v₁ + m₂v₂ (1 = shotgun, 2 = bullet). The left side is 0 since the initial velocity is 0.",
            ],
        },

        "q2": {
            "title": "QUEST 2 - G.U.E.S.A.",
            "psize": 19,
            "problem": "An outlaw enforcer with a mass of 105 kg stands at rest on the depot platform, waiting to ambush the Player. Rushing down the elevated line to tackle him, the Player with a mass of 85 kg charges forward at an initial velocity of +7.0 m/s. The Player grabs hold of the enforcer in a perfectly inelastic collision, and they slide together across the wooden platform after impact. Find their shared final velocity and the total kinetic energy lost in the tackle.",
            "left": [
                ("G - MASS OF PLAYER, m₁", "q2_m1", "Mass with unit"),
                ("G - INITIAL VELOCITY OF PLAYER, V₁", "q2_u1", "Velocity with sign and unit"),
                ("G - MASS OF ENFORCER, m₂", "q2_m2", "Mass with unit"),
                ("G - INITIAL VELOCITY OF ENFORCER, u₂", "q2_u2", "Velocity with unit"),
            ],
            "right": [
                ("U - UNKNOWNS (name both)", "q2_unknown", "What are we solving for?"),
                ("E - EQUATION", "q2_equation", "Write the equation"),
                ("S - SOLUTION", None, None),
                ("A - FINAL VELOCITY, vf", "q2_vf", "Value with sign and unit"),
                ("A - KINETIC ENERGY LOST", "q2_ke", "Value with unit"),
            ],
            "hints": [
                "HINT 1: Use momentum conservation: m₁u₁ + m₂u₂ = (m₁ + m₂)vf.",
                "HINT 2: Kinetic energy lost = KEᵢ − KEf, where KE = ½mv².",
            ],
        },

        "q3": {
            "title": "QUEST 3 - G.U.E.S.A.",
            "psize": 18,
            "problem": "During a daring escape from the abandoned Silver Spur Mine, Colm's outlaws shove a heavily reinforced mine cart packed with loot, massing 80 kg, down a sloped track at a high speed of +8.0 m/s toward the rail switch. To prevent the cart from smashing into the town station, the Player flips a heavy spring-actuated rail switch, forcing an ideal one-dimensional elastic collision between the moving loot cart and an empty 40 kg iron switch-cart standing completely stationary at the rail junction.\n1. What are the final velocities of the loot cart and the stationary switch-cart after the elastic collision?\n2. Did the loot cart bounce backward or continue moving forward after hitting the switch-cart?",
            "left": [
                ("G - MASS OF LOOT CART, m₁", "q3_m1", "Mass with unit"),
                ("G - INITIAL VELOCITY OF LOOT CART, V₁", "q3_u1", "Velocity with sign and unit"),
                ("G - MASS OF SWITCH-CART, m₂", "q3_m2", "Mass with unit"),
                ("G - INITIAL VELOCITY OF SWITCH-CART, u₂", "q3_u2", "Velocity with unit"),
                ("U - UNKNOWNS", "q3_unknown", "What are we solving for?"),
            ],
            "right": [
                ("E - EQUATION", "q3_equation", "Write the equation"),
                ("S - SOLUTION", None, None),
                ("A - FINAL VELOCITY OF LOOT CART, v₁f", "q3_v1f", "Value with sign"),
                ("A - FINAL VELOCITY OF SWITCH-CART, v₂f", "q3_v2f", "Value with sign"),
                ("A - DIRECTION OF LOOT CART", "q3_dir", "Forward or backward"),
            ],
            "hints": [
                "HINT 1: For objects with different masses use v₁f = (m₁ − m₂)/(m₁ + m₂) · v₁i and v₂f = 2m₁/(m₁ + m₂) · v₁i.",
                "HINT 2: Signs dictate the direction of the object.",
            ],
        },

        "q4": {
            "title": "QUEST 4 - G.U.E.S.A.",
            "psize": 19,
            "problem": "While transporting supplies to Oakhaven, a 120-kg railway cart travels eastward at +5.0 m/s. It collides with a stationary 80-kg cart carrying wooden crates. Due to the impact, their coupling mechanisms lock together, causing both carts to move as one.\n1. What is the final velocity of the two carts immediately after the collision?\n2. How much kinetic energy is lost during the collision?",
            "left": [
                ("G - MASS OF RAILWAY CART, m₁", "q4_m1", "Mass with unit"),
                ("G - INITIAL VELOCITY OF RAILWAY CART, V₁", "q4_u1", "Velocity with sign and unit"),
                ("G - MASS OF CRATE CART, m₂", "q4_m2", "Mass with unit"),
                ("G - INITIAL VELOCITY OF CRATE CART, u₂", "q4_u2", "Velocity with unit"),
                ("U - UNKNOWNS (name both)", "q4_unknown", "What are we solving for?"),
            ],
            "right": [
                ("E - EQUATION", "q4_equation", "Write the equation"),
                ("S - SOLUTION", None, None),
                ("A - FINAL VELOCITY, vf", "q4_vf", "Value with sign and unit"),
                ("A - KINETIC ENERGY LOST", "q4_ke", "Value with unit"),
            ],
            "hints": [
                "HINT 1: Use momentum conservation: m₁u₁ + m₂u₂ = (m₁ + m₂)vf.",
                "HINT 2: Kinetic energy lost = KEᵢ − KEf, where KE = ½mv².",
            ],
        },

        "q5": {
            "title": "QUEST 5 - G.U.E.S.A.",
            "psize": 18,
            "problem": "During the final confrontation at the Oakhaven railway junction, Selena Colm attempts to escape aboard a heavily loaded supply cart with a mass of 180 kg, traveling eastward at 6.0 m/s. To stop her escape, the Player positions a stationary defensive cart with a mass of 120 kg directly along the railway track. Upon impact, the two carts become locked together and move as one. Assuming that external impulse is negligible, determine:\n1. The final velocity of the two carts immediately after the collision.\n2. The kinetic energy lost during the collision.\n3. The direction the combined carts will move.",
            "left": [
                ("G - MASS OF SUPPLY CART, m₁", "q5_m1", "Mass with unit"),
                ("G - INITIAL VELOCITY OF SUPPLY CART, V₁", "q5_u1", "Velocity with direction and unit"),
                ("G - MASS OF DEFENSIVE CART, m₂", "q5_m2", "Mass with unit"),
                ("G - INITIAL VELOCITY OF DEFENSIVE CART, u₂", "q5_u2", "Velocity with unit"),
                ("U - UNKNOWNS (name all three)", "q5_unknown", "What are we solving for?"),
            ],
            "right": [
                ("E - EQUATION", "q5_equation", "Write the equation"),
                ("S - SOLUTION", None, None),
                ("A - FINAL VELOCITY, vf", "q5_vf", "Value with sign and unit"),
                ("A - KINETIC ENERGY LOST", "q5_ke", "Value with unit"),
                ("A - DIRECTION OF THE COMBINED CARTS", "q5_dir", "Direction"),
            ],
            "hints": [
                "HINT 1: Use momentum conservation: m₁u₁ + m₂u₂ = (m₁ + m₂)vf.",
                "HINT 2: Kinetic energy lost = KEᵢ − KEf, where KE = ½mv².",
                "HINT 3: The sign of vf tells you the direction of motion.",
            ],
        },

                "q5": {
            ...
        },
    }

    quest_defs["q13"] = {
        "title": "QUEST 1.3 - G.U.E.S.A.",
        "psize": 22,
        "problem": "A steel railway ball is dropped onto a hard steel plate. It approaches the plate at a speed of 10 m/s and rebounds upward at a speed of 8 m/s.\n1. What is the coefficient of restitution (e) of this impact?\n2. What type of collision is it?",
        "left": [
            ("G - GIVEN: APPROACH SPEED", "q13_v1", "Speed with unit"),
            ("G - GIVEN: REBOUND SPEED", "q13_v2", "Speed with unit"),
            ("U - UNKNOWN", "q13_unknown", "What are we solving for?"),
            ("E - EQUATION", "q13_equation", "Write the equation"),
        ],
        "right": [
            ("S - SOLUTION", None, None),
            ("A - COEFFICIENT OF RESTITUTION, e", "q13_e", "Value (no unit)"),
            ("A - TYPE OF COLLISION", "q13_type", "Elastic, inelastic or perfectly inelastic"),
        ],
        "hints": [
            "HINT 1: e = relative speed after collision ÷ relative speed before collision.",
            "HINT 2: The plate does not move, so e = rebound speed ÷ approach speed.",
            "HINT 3: e = 1 is perfectly elastic, 0 < e < 1 is inelastic, e = 0 is perfectly inelastic.",
        ],
    }

   

screen qf(item):
    if item[1] is None:
        vbox:
            spacing 4
            text "S - SOLUTION" size 22 bold True color "#D9A441"
            if guesa_solution_drawn:
                text "Whiteboard work saved." size 18 italic True color "#80E080"
            else:
                text "Show your solution on the whiteboard." size 18 italic True color "#8A7A66"
    else:
        use guesa2_field(item[0], item[1], getattr(store, item[1]), item[2])


screen quest_form(key):

    modal True
    zorder 200

    default hint_level = 0

    $ q = quest_defs[key]

    add Solid("#17100B")

    frame:
        xalign 0.5
        yalign 0.5
        xsize 1500
        ysize min(960, config.screen_height - 60)
        background Solid("#3B281E")
        padding (35, 20)

        fixed:
            xfill True
            yfill True

            vbox:
                spacing 10
                xfill True

                text q["title"]:
                    size 36
                    bold True
                    color "#D9A441"
                    xalign 0.5

                text q["problem"]:
                    size q["psize"]
                    color "#FFF1DD"
                    xalign 0.5
                    text_align 0.5
                    xmaximum 1350

                hbox:
                    xalign 0.5
                    spacing 40

                    vbox:
                        spacing 8
                        if len(q["left"]) > 0:
                            use qf(q["left"][0])
                        if len(q["left"]) > 1:
                            use qf(q["left"][1])
                        if len(q["left"]) > 2:
                            use qf(q["left"][2])
                        if len(q["left"]) > 3:
                            use qf(q["left"][3])
                        if len(q["left"]) > 4:
                            use qf(q["left"][4])

                    vbox:
                        spacing 8
                        if len(q["right"]) > 0:
                            use qf(q["right"][0])
                        if len(q["right"]) > 1:
                            use qf(q["right"][1])
                        if len(q["right"]) > 2:
                            use qf(q["right"][2])
                        if len(q["right"]) > 3:
                            use qf(q["right"][3])
                        if len(q["right"]) > 4:
                            use qf(q["right"][4])

                if hint_level >= 1:
                    frame:
                        xfill True
                        background "#F5EBD8"
                        padding (15, 8)
                        vbox:
                            spacing 4
                            for i in range(hint_level):
                                text q["hints"][i]:
                                    color "#2A1A10"
                                    size 18
                                    xfill True
                                    text_align 0.5

            hbox:
                xalign 0.5
                yalign 1.0
                spacing 15

                textbutton "HINT":
                    action SetScreenVariable("hint_level", min(hint_level + 1, len(q["hints"])))
                    xsize 300
                    ysize 60
                    background "#3A2418"
                    hover_background "#513522"
                    text_color "#FFFFFF"
                    text_hover_color "#D9A441"
                    text_size 24
                    text_xalign 0.5
                    text_yalign 0.5

                textbutton "WHITEBOARD":
                    action Show("whiteboard_screen", problem=q["problem"])
                    xsize 300
                    ysize 60
                    background "#3A2418"
                    hover_background "#513522"
                    text_color "#FFFFFF"
                    text_hover_color "#D9A441"
                    text_size 24
                    text_xalign 0.5
                    text_yalign 0.5

                textbutton "SUBMIT":
                    action Return("submit")
                    xsize 300
                    ysize 60
                    background "#3A2418"
                    hover_background "#513522"
                    text_color "#FFFFFF"
                    text_hover_color "#D9A441"
                    text_size 24
                    text_xalign 0.5
                    text_yalign 0.5


# ==========================================
# CHAPTER 2 - STEP 1: GIVEN
# ==========================================

screen given_input_2():

    modal True
    zorder 200

    add Solid("#000000B8")

    frame:
        xalign 0.5
        yalign 0.5
        xsize 1000
        background "#2A1A10"
        padding (40, 30)

        vbox:
            spacing 14
            xfill True

            text "STEP 1 - GIVEN":
                size 32
                bold True
                color "#D9A441"
                xalign 0.5

            text "A heavy wooden supply cart with a mass of 150 kg is rolling down Oakhaven's sloped street with an initial velocity of 4.0 m/s. To prevent it from crashing into the mercantile porch, the Player would have to throw an iron coupling chain that locks the rolling cart to a stationary timber cart with a mass of 50 kg (V₂ = 0 m/s). Assuming the collision is perfectly inelastic, what is the final velocity of the two carts after the collision?":
                size 20
                color "#F5EBD8"
                xfill True
                text_align 0.5

            use guesa2_field("MASS OF OBJECT 1 (SUPPLY CART), m₁ (kg)", "ch2_m1", ch2_m1, "kg")
            use guesa2_field("INITIAL VELOCITY OF OBJECT 1, V₁ (m/s)", "ch2_V1", ch2_V1, "m/s")
            use guesa2_field("MASS OF OBJECT 2 (TIMBER CART), m₂ (kg)", "ch2_m2", ch2_m2, "kg")
            use guesa2_field("INITIAL VELOCITY OF OBJECT 2, V₂ (m/s)", "ch2_V2", ch2_V2, "m/s")

            null height 5

            textbutton "SUBMIT":
                action Return("submit")
                xalign 0.5
                xsize 300
                ysize 60
                background "#3A2418"
                hover_background "#513522"
                text_color "#FFFFFF"
                text_hover_color "#D9A441"
                text_size 24
                text_xalign 0.5
                text_yalign 0.5


# ==========================================
# CHAPTER 2 - STEP 3: SOLVE FOR FINAL VELOCITY
# ==========================================

screen solve_input_2():

    modal True
    zorder 200

    default hint_level = 0

    $ problem_text = "A heavy wooden supply cart with a mass of 150 kg is rolling down Oakhaven's sloped street with an initial velocity of 4.0 m/s. To prevent it from crashing into the mercantile porch, the Player would have to throw an iron coupling chain that locks the rolling cart to a stationary timber cart with a mass of 50 kg (V₂ = 0 m/s). Assuming the collision is perfectly inelastic, what is the final velocity of the two carts after the collision?"

    add Solid("#000000D0")

    frame:
        xalign 0.5
        yalign 0.5
        xsize 1000
        background "#2A1A10"
        padding (40, 30)

        vbox:
            spacing 16
            xfill True

            text "STEP 3 - SOLVING FOR FINAL VELOCITY":
                size 32
                bold True
                color "#D9A441"
                xalign 0.5

            text problem_text:
                size 20
                color "#F5EBD8"
                xfill True
                text_align 0.5

            text "600 kg·m/s = (150 kg + 50 kg)vf = (200 kg)vf":
                size 24
                bold True
                color "#FFFFFF"
                xalign 0.5

            use guesa2_field("FINAL VELOCITY, vf", "ch2_vf", ch2_vf, "Value with unit")

            if hint_level >= 1:
                frame:
                    xfill True
                    background "#F5EBD8"
                    padding (15, 10)
                    vbox:
                        spacing 6
                        text "HINT 1: Divide both sides of the equation by the total combined mass.":
                            color "#2A1A10"
                            size 20
                            xfill True
                            text_align 0.5
                        if hint_level >= 2:
                            text "HINT 2: vf = (600 kg·m/s) ÷ (200 kg)":
                                color "#2A1A10"
                                size 20
                                xfill True
                                text_align 0.5

            hbox:
                xalign 0.5
                spacing 15

                textbutton "HINT":
                    action SetScreenVariable("hint_level", min(hint_level + 1, 2))
                    xsize 280
                    ysize 60
                    background "#3A2418"
                    hover_background "#513522"
                    text_color "#FFFFFF"
                    text_hover_color "#D9A441"
                    text_size 24
                    text_xalign 0.5
                    text_yalign 0.5

                textbutton "WHITEBOARD":
                    action Show("whiteboard_screen", problem=problem_text)
                    xsize 280
                    ysize 60
                    background "#3A2418"
                    hover_background "#513522"
                    text_color "#FFFFFF"
                    text_hover_color "#D9A441"
                    text_size 24
                    text_xalign 0.5
                    text_yalign 0.5

                textbutton "SUBMIT":
                    action Return("submit")
                    xsize 280
                    ysize 60
                    background "#3A2418"
                    hover_background "#513522"
                    text_color "#FFFFFF"
                    text_hover_color "#D9A441"
                    text_size 24
                    text_xalign 0.5
                    text_yalign 0.5


# ==========================================
# CHAPTER 3 - STEP 1: GIVEN
# ==========================================

screen given_input_3():

    modal True
    zorder 200

    default hint_level = 0

    $ problem_text = "Selena Colm's gang is rolling an iron-plated safe with a mass of 50 kg down a narrow canyon path at an initial velocity of +6.0 m/s toward the Player's barricade. To deflect it without letting it break through, the Player uses a spring-loaded gate to trigger an ideal one-dimensional elastic collision with an identical stationary steel barrier of mass 50 kg. What are the final velocities of the iron-plated safe and the barrier after this elastic collision?"

    add Solid("#000000B8")

    frame:
        xalign 0.5
        yalign 0.5
        xsize 1000
        background "#3B281E"
        padding (35, 25)

        vbox:
            spacing 14
            xfill True

            text "G - GIVEN":
                size 34
                bold True
                color "#D9A441"
                xalign 0.5

            text problem_text:
                size 20
                color "#F5EBD8"
                xfill True
                text_align 0.5

            use guesa2_field("MASS OF THE ROLLING IRON SAFE (m₁)", "ch3_m1", ch3_m1, "Mass with unit")
            use guesa2_field("INITIAL VELOCITY OF THE SAFE (V₁)", "ch3_u1", ch3_u1, "Velocity with sign and unit")
            use guesa2_field("MASS OF THE STATIONARY STEEL BARRIER (m₂)", "ch3_m2", ch3_m2, "Mass with unit")
            use guesa2_field("INITIAL VELOCITY OF THE BARRIER (V₂)", "ch3_u2", ch3_u2, "Velocity with sign and unit")

            if hint_level >= 1:
                frame:
                    xfill True
                    background "#F5EBD8"
                    padding (15, 8)
                    text "HINT: Read the problem again. The barrier is identical to the safe, and it is stationary.":
                        color "#2A1A10"
                        size 20
                        xfill True
                        text_align 0.5

            null height 6

            hbox:
                xalign 0.5
                spacing 15

                textbutton "HINT":
                    action SetScreenVariable("hint_level", 1)
                    xsize 300
                    ysize 60
                    background "#3A2418"
                    hover_background "#513522"
                    text_color "#FFFFFF"
                    text_hover_color "#D9A441"
                    text_size 24
                    text_xalign 0.5
                    text_yalign 0.5

                textbutton "SUBMIT":
                    action Return("submit")
                    xsize 300
                    ysize 60
                    background "#3A2418"
                    hover_background "#513522"
                    text_color "#FFFFFF"
                    text_hover_color "#D9A441"
                    text_size 24
                    text_xalign 0.5
                    text_yalign 0.5


# ==========================================
# IMAGE-BASED STORY DIALOGUE (optional)
# ==========================================

screen image_story_dialogue(speaker, dialogue):

    zorder 100

    frame:
        xpos 170
        yalign 0.97
        xsize 1570
        ysize 230
        background "#CDB48A"
        padding (2, 2)

        frame:
            xfill True
            yfill True
            background "#120C09E6"
            padding (60, 40)

            text dialogue:
                size 27
                color "#F5EBD8"
                xalign 0.0
                yalign 0.5

    if speaker:

        frame:
            xpos 200
            yalign 0.97
            yoffset -230
            background "#CDB48A"
            padding (2, 2)

            frame:
                background "#2A1A10"
                padding (45, 8)

                text speaker:
                    size 25
                    bold True
                    color "#D9A441"

screen solution_card(title, steps):

    zorder 50

    frame:
        xalign 0.5
        yalign 0.06
        xsize 1300
        background "#D9A441"
        padding (2, 2)

        frame:
            xfill True
            background "#2A1A10"
            padding (35, 25)

            vbox:
                xfill True
                spacing 12

                text title:
                    size 26
                    bold True
                    color "#D9A441"
                    xalign 0.5

                null height 4

                for i, step in enumerate(steps):
                    text step:
                        size 32
                        bold (i == len(steps) - 1)
                        color ("#FFD27A" if i == len(steps) - 1 else "#FFFFFF")
                        xalign 0.5
                        text_align 0.5
                        xmaximum 1200

# ==========================================
# LEAVE TO MAIN MENU
# ==========================================

screen leave_to_menu():

    modal True
    zorder 400

    add Solid("#000000B8")

    key "game_menu" action Hide("leave_to_menu")

    frame:
        xalign 0.5
        yalign 0.5
        xsize 1050
        background "#2A1A10"
        padding (40, 30)

        vbox:
            spacing 25
            xfill True

            text "Do you want to save your progress":
                size 28
                color "#F5EBD8"
                xalign 0.5
                text_align 0.5

            hbox:
                xalign 0.5
                spacing 20

                textbutton "SAVE PROGRESS":
                    action [FileSave(1, confirm=False), MainMenu(confirm=False)]
                    style "box_button"
                    xsize 300

                textbutton "MAIN MENU":
                    action MainMenu(confirm=False)
                    style "box_button"
                    xsize 300

                textbutton "CANCEL":
                    action Hide("leave_to_menu")
                    style "box_button"
                    xsize 300